/* optimize larp and adrk and sbrk instructoins */

#include <stdio.h>
#include <string.h>
#include "mcout.h"

extern void error( char *p );

static char buf[ALL+1][100];   /* stage buffer */
static int id;                  /* current index */

char history[100];             /* last line staged */

char * p2tab( char *p ){  /* find 2nd tab in string */

   while( *p ) if( *p++ == '\t' ) break;
   while( *p && *p != '\t' ) ++p;
   return ++p;                     /* return just past tab */
}
      

void flush( int n ){     /* print out all up to n */
int i, k;



  for( i= 0; i <= n ; i++){ 
     if( i == id ) break;        /* reached current index */
     if( i == id - 1 && strstr(buf[i],"adrk")) break;  /* save adrk */
     printf("%s", &buf[i] );
     }


  /* see if any left */
  for( k= 0; ; k++, i++ ) {
     if( i == id ) break;
     strcpy( buf[k],buf[i] );    /* copy down the ones left */
     }

  id= k;                         /* k has new current index */
  buf[id][0]= 0;                 /* kill line */
}

void stage( char *p ){     /* put lines into the buffer */
char *e, *p2, *p3;
int len;
int iw;
char temp[100];
int val1, val2;

  strncat( buf[id], p, 100 ); 
  len= strlen( buf[id] );
  if( len > 100 ) error("Line is too long for stage buffer");

  if( buf[id][len-1] != '\n' ) return;  /* still more needed in this line */

  strcpy( history, buf[id] );           /* remember this line */

  iw= id++;     /* establish a working index, global is counted up */
  if( id == ALL ){ 
     flush(ALL); /* don't overfill the buffer */
     return;
     }
  buf[id][0]= 0;                 /* kill next line */

  /* do optimizations */
  
  if( buf[iw][0] == ';' ) return;  /* just a comment */
  
  if( strchr( buf[iw], '*' ) != 0 ){
     /* this one uses indirect mode - flush all previous */
     flush( iw - 1 );
     return;
     }

  /* optimize out a few obvious not needed */
  if( strcmp( buf[iw],"\trptk\t0\n") == 0 ){  /* repeat zero times */
     buf[iw][0]= ';';
     return;
     }
  if( strcmp( buf[iw],"\tsubk\t0\n") == 0 ){  /*  == 0 in compare */
     buf[iw][0]= ';';
     return;
     }



  e= strchr( buf[0], '*') ;    /* find potential optimize place */
  if( buf[0][0] == ';' ) e= 0;        /* don't sub into comments */
  if( strstr( e,",ar" ) != 0 ) e= 0;  /* already has one */
  
  /* larp optimize */

  if( strstr( buf[iw],"larp") != 0 ){   /* this one is a larp */
     if( e != 0 ){                   /* check buf zero for * */
        /* do the optimize */   
        p2= p2tab( buf[iw] );         /* point to ar? */
        while( *e != '\n' ) ++e;      /* find end of target */
        *e= 0;
        strcat( buf[0], ",");
        strcat( buf[0], p2 );
        buf[iw][0] = ';' ;            /* kill this line */
        }
     flush(ALL);
     return;
     }


  /* adrk  sbrk optimize */
  if( strstr( buf[iw],"sbrk") != 0){
     if( e != 0 ){
        /* do the optimize */
        if( *++e != '+' && *e != '-' ){     /* hasn't been done */
           p2= p2tab( buf[iw] );
           if( strcmp( p2,"1\n") == 0 ){        /* only one */
              p3= temp;
              p2= buf[0];
              while ( p2 != e ) *p3++ = *p2++;  /* copy string */
              *p3++ = '-';                      /* insert - */
              while ( *p3++ = *p2++ );         /* copy rest of it */
              strcpy( buf[0],temp );
              buf[iw][0] = ';';
              }
           }
        }
     flush(ALL);
     return;
     }
  /* adrk  sbrk optimize */
  if( strstr( buf[iw],"adrk") != 0){
     if( iw > 0 && strstr(buf[iw-1],"adrk")){  /* two in a row */
        p2= p2tab( buf[iw] );
        p3= p2tab( buf[iw-1] );
        sscanf(p2,"%d",&val1);  sscanf(p3,"%d",&val2);
        sprintf(buf[iw],"\tadrk\t%d\n",val1 + val2);
        buf[iw-1][0]= ';';
        }

     else if( e != 0 ){
        /* do the optimize */
        if( *++e != '+' && *e != '-' ){     /* hasn't been done */
           p2= p2tab( buf[iw] );
           if( *p2 == '1' ){                /* only one */
              p3= temp;
              p2= buf[0];
              while ( p2 != e ) *p3++ = *p2++;  /* copy string */
              *p3++ = '+';                      /* insert + */
              while ( *p3++ = *p2++ );         /* copy rest of it */
              strcpy( buf[0],temp );
              buf[iw][0] = ';';
              }
           }
        }
     flush(ALL);
     return;
     }

}


     
