
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "mcsym.h"
#include "mcc.h"
#include "mcexp.h"
#include "mcsub.h"
#include "mcout.h"
#include "mcvar.h"

extern char word[];
extern char *lp;
extern int jumpval;
extern int label;

int conditional;   /* flag conditional expression so can sign extend */
int compared;  /* flag to fix && ( x & 2 ) type expression */

/* expression parsing */

void passign( struct EVAL *p );


/*
              ,  done in expression()
passign       = += -= /= *= %= <<= >>= &= ^= |=     R to L
pconditional  ?:                                    R to L
plogor        ||
plogand       &&
por           |
pxor          ^
pand          &
pequal        == !=
pgtlt         < <= >= >
pshift        << >>
padd          + -
pmul          * / %
punary        ! ~ -  (cast)  * & ++ -- sizeof   R to L
primary       (expression)  struct.member   [array]   structp->member
*/



extern void pointeradd( struct EVAL *e1, struct EVAL *e2, int op );

int stackout;
int stackin;


void primary( struct EVAL *e1 ){
struct SYMBOL *ps;
struct EVAL e2;
int save;
char *p;
extern int shortcall;


   e1->type= 0;
   e1->val= 0;
   e1->datasize= 0;
   e1->reg= 0;


/* 12/94 try this before funcall */

   if( match("(") ){     /* it is a new expression */
      next();
      passign( e1 );
      if( match(")") == 0 )error("Expected paren");
      if( *lp != '(' ){
         next();  /* else is a call indirect */
         goto skipfun;
         }
      }


   if( *lp == '(' ){    /* its a function call */
      if( e1->type == ADDRESS ){  /* call via pointer */
         e1->type= VALUE;
         loadval( e1 );      /* get address to accum C26 */
         }

      if( e1->type != VALUE ) {
         if( ps= findsym( word )){
            copysymbol( &e1->var,ps );
            e1->type= FOUND;
            }
         else{          /* not defined yet */
            e1->var.ident=FUNCTION;
            strcpy( &e1->var.name, word );
            e1->var.type= INT;   /* the default return value */
            e1->type= FUNCALL;
            }
         }
    /* type is now VALUE - call via pointer, or FUNCALL - an undefined name
       or FOUND - a previously defined symbol */

   /*  set a flag if name has leading underscore - for C26 lib functions */
      if( word[0] == '_' ) shortcall= 1;

      prefun();
      next();  next();
      while( lp ){   /* get arguments */
         if( match(")") ) break;
         passign( &e2 );
         storearg( &e2 );
         if( match(",") ) {
            next();
            continue;
            }
         if( match(")") == 0 ){
            error("Missing paren or comma");
            break;
            }
         }

      callfun( e1 );
      postfun();
   /*   e1->type= VALUE;   /* any return value is in the registers */
     e1->type= FUNCALL;    /* allow to call loadval so jumps are correct */
      e1->var.ident= VAR;
      next();
      return;
      }

skipfun:

   if( constval( e1 )) return;

   if( word[0] == '"' ){   /* string literal */
      p= addlit();
      e1->reg= loadlit( p );
      e1->type= VALUE;
      e1->var.ident= VAR;
      e1->datasize= SOP;
      next();
      return;
      }




   if( ps = findsym( word ) ){     /* should match if gets this far */
      e1->type= FOUND;
      copysymbol( &e1->var, ps );
      next();
      }


   if( e1->type == 0 ){
    /*  printf("parse error on %s\n",word); */
      error("Syntax error - undeclared var?");
      }



while(1){

   if( match(".") ) {  /* member */
      next();
      findmember( e1 );
      next();
      e1->val+= e1->var.offset;
      if( e1->type != FOUND ) address( e1 );
      continue;
      }



   if( match("->")) { /* point to member */
      if( e1->var.ident != POINTER ) error("Not a pointer");
      next();
      save= e1->var.indirect;
      findmember( e1 );
      e1->var.indirect+= save -1 ;
      next();
      if( e1->var.offset ){
         e2.type= CONSTANT;
         e2.val= e1->var.offset;
         e2.datasize= SOP;
         save= e1->var.ident;
         e1->var.ident= POINTER;
         doop( e1, &e2 , '+' );
         e1->type= ADDRESS;
         e1->datasize= 0;
         if( e1->var.indirect == 0 ) e1->var.ident= save;
         }
      continue;
      }


   if( match("[")){   /* its an array */
      next();
      passign( &e2 );
      if( e1->type != FOUND ) e1->type= VALUE;
      pointeradd( e1, &e2,'+');

      if( e1->var.ident == POINTER ) {
         e1->var.indirect -= 1;
         if( e1->var.indirect == 0 ) e1->var.ident= VAR;
         }
      else if( e1->var.ident == ARRAY ){
         if( e1->var.size2 ) e1->var.size2= 0;
         else if( e1->var.size ){
            e1->var.size= 0;
            e1->var.ident= VAR;
            }
         }
      else error("Not an array");

      if( match("]") == 0 ) error("Expected ]");
      next();
      if( e1->type == VALUE ){
         e1->type= ADDRESS;
         }
      e1->datasize= 0;
      continue;
      } /* end array */

   break;  /* no more array or struct members */
   }    /* end while */

}


void punary( struct EVAL *e1 ){
int op;


   if( match("(")){
      next();
      if( match("int") || match("char") || match("long") ||
          match("struct") || match("double") || match("float") ||
          match("union") || match("short") || match("unsigned") ||
          match("signed") || match("void") ){
          /* cast the value */

          }
      else{
          unnext();
          strcpy(word,"(");    /* not this level */
          }
      }


   if( match("sizeof")){

   }


   if( match("-") ){
      next();
      punary( e1 );
      if( e1->type == CONSTANT ) e1->val = - e1->val;
      else{               /* gen some code */
         loadval( e1 );
         negate();
         }
      return;
      }

   if( match("!") ){               /* the in and out conditions are */
      stackout= stackin= -1;       /* swapped at the end of the exp */
      next();
      punary( e1 );
      if( e1->type != VALUE ){
         jumpval= JNE;
         loadval( e1 );
         }
      jumpval= -jumpval;
      if( stackout == -1 ) stackout= label++;
      jump( stackout );                       /* this is really a jump in */
      jumpval= ALWAYS;                                    /* because */
      if( stackin != -1 ) pilabel( stackin );                /* we */
      stackin= stackout;                     /* swap the in and out labels */
      stackout= -1;               /* and jump always out at the in label */
      return;
      }

   if( match("~") ){
      next();
      punary( e1 );
      loadval( e1 );
      compliment();
      return;
      }


   if( match("*") ){      /* pointer */
      next();
      punary( e1 );
      if( e1->type != VALUE && e1->type != STACKVAL ) loadadd( e1 );
      if( !(e1->var.ident == ARRAY || e1->var.ident == POINTER) )
          error("Not a pointer");
      if( e1->var.ident == POINTER ){
         e1->var.indirect -= 1;           /* dec the indirect count */
         /* if the count is zero, we now have address of var of type */
         /* otherwise it is an address of a pointer */
         if(e1->var.indirect == 0 ){
            /* check for a link */
            if( e1->var.type == LINK ){
               /* copy over the stuff we want */
               e1->var.type= (e1->var.link)->type;
               e1->var.ident= (e1->var.link)->ident;
               e1->var.size= (e1->var.link)->size;
               e1->var.size2= (e1->var.link)->size2;
               e1->var.indirect= (e1->var.link)->indirect;
               }
            else e1->var.ident= VAR;     /* no link, just VAR */
            }
         if( e1->type == STACKVAL ) e1->type= STACKADD;
         else e1->type= ADDRESS;
         e1->datasize= 0;
         return;
         }
      else{      /* its an array */
         if( e1->var.size2 ) e1->var.size2= 0;
         else if( e1->var.size ){
            e1->var.size= 0;
            e1->var.ident= VAR;
            }
         else error("Not an array");
         e1->type= ADDRESS;
         e1->datasize= 0;
         return;
         }
      }   /* end  pointer */

   if( match("++") || match("--") ){
      op= word[0];
      next();
      punary( e1 );
      preincdec( e1, op );
      return;
      }

   if( match("&") ){
      next();
      punary( e1 );
      address( e1 );
      e1->type= VALUE;  /* address was desired value */
      e1->datasize= SOP;
      return;
      }


   if( match("@") ){   /* in expression */
      next();
      primary( e1 );
      pinport( e1 );
      e1->type= VALUE;
      return;
      }

   primary( e1 );


   if( match("++") || match("--") ){
      op= word[0];
      next();
      postincdec( e1, op );
      return;
      }


}


void pmul( struct EVAL *e1 ){
struct EVAL e2;
int op;

     punary( e1 );

     while( match("*") || match("/") || match("%") ){
        op= word[0];
        next();
        tempval( e1 );
        punary( &e2 );
     /* constants only ? - just evaluate the expression */
        if( e1->type == CONSTANT && e2.type == CONSTANT ){
           switch( op ){
              case '*':  e1->val *= e2.val;  break;
              case '/':  e1->val /= e2.val;  break;
              case '%':  e1->val %= e2.val;  break;
              }
           continue;
           }
     /* else generate some code */
        doop( e1, &e2, op );
        } /* end while */
}



void padd( struct EVAL *e1 ){
struct EVAL e2;
int op;

     pmul( e1 );

     while( match("+") || match("-") ){
        op= word[0];
        next();
        tempval( e1 );
        pmul( &e2 );
     /* constants only ? - just evaluate the expression */
        if( e1->type == CONSTANT && e2.type == CONSTANT ){
           switch( op ){
              case '+':  e1->val+= e2.val;  break;
              case '-':  e1->val-= e2.val;  break;
              }
           continue;
           }
        /* else generate some code */
        if( e1->type != CONSTANT  &&
           (e1->var.ident == POINTER || e1->var.ident == ARRAY) )
            pointeradd( e1, &e2, op );
        else doop( e1, &e2, op );

        }  /* end while */
}


void pshift( struct EVAL *e1 ){
struct EVAL e2;
int op;

   padd( e1 );
   while( match(">>") || match("<<") ){
      op= word[0];
      next();
      tempval( e1 );
      padd( &e2 );

      if( e1->type == CONSTANT && e2.type == CONSTANT ){
         switch( op ){
            case '>':  e1->val>>= e2.val;  break;
            case '<':  e1->val<<= e2.val;  break;
            }
         continue;
         }
        /* else generate some code */
        doop( e1, &e2, op );

        }  /* end while */

}

void pgtlt( struct EVAL *e1 ){    /* <  <=  >=  >  */
struct EVAL e2;
int op;

   pshift( e1 );

   while( match("<") || match(">=") || match("<=") || match(">") ){
      compared= 1;
      op= word[0] + word[1];
      next();
      tempval( e1 );
      pshift( &e2 );
      switch( op ){
         case '<':  jumpval= JL;   break;
         case '>':  jumpval= JG;   break;
         case '>' + '=':  jumpval= JGE;  break;
         case '<' + '=':  jumpval= JLE;  break;
         }
      compare( e1, &e2 );
      }

}

void pequal( struct EVAL *e1 ){     /* == and != */
struct EVAL e2;
int op;

   pgtlt( e1 );

   while( match("==") || match("!=") ){
      compared= 1;
      op= word[0];
      next();
      tempval( e1 );
      pgtlt( &e2 );
      if( op == '=' ) jumpval= JE;    /* define jumpval before compare */
      else jumpval= JNE;
      compare( e1, &e2 );
      }

}

void pand( struct EVAL *e1 ){
struct EVAL e2;

   pequal( e1 );

     while( match("&") ){
        next();
        tempval( e1 );
        pequal( &e2 );

     /* constants only ? - just evaluate the expression */
        if( e1->type == CONSTANT && e2.type == CONSTANT ){
           e1->val &= e2.val;
           continue;
           }
        /* else generate some code */
        doop( e1, &e2, '&' );

        }  /* end while */


}

void pxor( struct EVAL *e1 ){
struct EVAL e2;

   pand( e1 );

     while( match("^") ){
        next();
        tempval( e1 );
        pand( &e2 );

     /* constants only ? - just evaluate the expression */
        if( e1->type == CONSTANT && e2.type == CONSTANT ){
           e1->val ^= e2.val;
           continue;
           }
        /* else generate some code */
        doop( e1, &e2, '^');

        }  /* end while */


}

void por( struct EVAL *e1 ){
struct EVAL e2;

   pxor( e1 );

     while( match("|") ){
        next();
        tempval( e1 );
        pxor( &e2 );

     /* constants only ? - just evaluate the expression */
        if( e1->type == CONSTANT && e2.type == CONSTANT ){
           e1->val |= e2.val;
           continue;
           }
        /* else generate some code */
        doop( e1, &e2, '|' );

        }  /* end while */


}

void plogand( struct EVAL *e1 ){
int outlabel;

   por( e1 );

   if( match("&&")){
      outlabel= label++;
      while( match("&&") ){
         if( e1->type != VALUE ){    /* load single ops */
            loadval( e1 );
            jumpval= JNE;
            }
         if( compared == 0 ) jumpval= JNE;
         jumpval= -jumpval;
         jump( outlabel );
         if( stackin != -1 ){
            pilabel( stackin );
            stackin= -1;
            }
         next();
         compared= 0;
         por( e1 );
         }
      stackout= outlabel ;
      }
}


void plogor( struct EVAL *e1 ){
int inlabel;

   plogand( e1 );

   if( match("||") ){
      inlabel= label++;
      while( match("||") ){
         if( e1->type != VALUE ){    /* load single ops */
            loadval( e1 );
            jumpval= JNE;
            }
         jump( inlabel );
         if( stackout != -1 ){
           pilabel(stackout);
           stackout= -1;
           }
         next();
         compared= 0;
         plogand( e1 );
         }
      stackin= inlabel;
      }
}


void pconditional( struct EVAL *e1 ){
int lab;
int lab2;
struct EVAL e2;

   plogor( e1 );
   if( match("?")){
      if( e1->type != VALUE ){
         loadval( e1 );
         jumpval= JNE;
         }
      jumpval= -jumpval;
      if( stackin != -1 ) pilabel( stackin );
      if( stackout != -1 ) lab= stackout;
      else lab= label++;
      jump( lab );
      next();
      cexpression();
      if( match(":") == 0 ) error("Expected colon");
      lab2= label++;
      jumpval= ALWAYS;
      jump( lab2 );
      pilabel( lab );
      next();
      cexpression();       /* use cexpression to eval single op */
      pilabel( lab2 );
      e1->type= VALUE;
      }

/* add  out instruction */
   if( match("$") ){
      next();
      loadval( e1 );
      plogor( &e2 );
      poutport( &e2 );
      }


}

void passign( struct EVAL *e1 ){
struct EVAL e2;
int op, reg, temp;
extern int c26;   /* flag for conditional execution */
extern int pic;   /* ditto */


   pconditional( e1 );

   while( match("=") || match("+=") || match("-=") ||
          match("*=") || match("/=") || match("%=") ||
          match("<<=") || match(">>=") || match("&=") ||
          match("|=") || match("^=")  ){
     op= word[0];
     if( op != '=' ) {   /**** save address and load value */

              /* code for pic, should be two instructions */
        if( pic && e1->var.ident == VAR ){

           next();
           passign(&e2);
           doopstore(e1,&e2,op);

        }

        else{       /* normal for all other, c26 8085 pic pointer arrays */
       /* try this the old way again */
        address( e1 );
        temp= e1->reg;  /* save the register used c26 - replaces push */

        if( c26 == 0 && pic == 0 ) push(e1);     /* save address */
        else pushadd();

        tempval( e1 );              /* load data */
        next();
        passign( &e2 );

/* special code for pointers */
        if( e1->var.ident == POINTER && ( op == '+' || op == '-' ) )
          pointeradd( e1, &e2, op );

        else doop( e1, &e2, op );
        reg= e1->reg;               /* save where result ended up */

        if( c26 == 0 && pic == 0 ) pop(e1);      /* restore address */
        else popadd();
        e1->type= ADDRESS;
        e1->reg= temp;              /* restore what reg has address */

        store( e1,reg );
        }
        }

      /* plain assignment, no operation */

     else{
        if( e1->type != FOUND ){
         /* should be address, save it */
          if( c26 == 0 && pic == 0 ){
           if( e1->type != STACKADD ) push(e1);
           }
          else pushadd();

           next();
           passign( &e2 );
           loadval( &e2 );
         if( c26 == 0 && pic == 0 ) pop(e1);   /* restore address */
         else popadd();

           e1->type= ADDRESS;

           e1->datasize= size( &e1->var );
           cast( &e2, e1->datasize );
           store( e1, e2.reg );
           }
        else{         /* generate address in func store */
           next();
           passign( &e2 );
           loadval( &e2 );
           e1->datasize= size( &e1->var );
           cast( &e2, e1->datasize );
           store( e1, e2.reg );
           }
        }
     }    /* end while */
}


void cexpression(){    /* evaluates single ops */
struct EVAL e1;
extern int flags;
extern int pic;

   conditional= 1;  /* tell output gen to sign extend */
   if( match(";") || match(")") || match("}") ) return;
   flags= 0;
   stackin= stackout= -1;
   while(lp){
     compared= 0;
     passign( &e1 );
     if( e1.type != VALUE ){    /* load single ops */
        status( &e1 );
        jumpval= JNE;
        }
     if( compared == 0 ) jumpval= JNE;
     if( match(",") == 0 ) break;    /* comma operator */
     next();
     }
  if(( e1.type == STACKVAL || e1.type == STACKADD )) pop( &e1 );
  conditional= 0;
}


void expression(){
struct EVAL e1;
extern int flags;
extern int pic;


   if( match(";") || match(")") || match("}") ) return;
   flags= 0;
   stackin= stackout= -1;
   while(lp){
     passign( &e1 );
     if( match(",") == 0 ) break;    /* comma operator */
     next();
     }
  if( match(";") || match("}" )) ;        /* ok */
/* ---false error in for loop---  else error("Missing semi or bracket"); */
  if( (e1.type == STACKVAL || e1.type == STACKADD)
      && pic == 0 ) pop( &e1 );

}


long const_exp( ){    /* evaluates a required constant expression */

struct EVAL e1;

   passign( &e1 );
   if( e1.type != CONSTANT ) error("Integer constant required");
   unnext();
   return e1.val;
}


