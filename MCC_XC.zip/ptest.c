

#include <pic16f84.h> 
#pragma bsr

char t1;
char t2;
extern char eevals[] = {5,3,2,9};

main(){


   if( t1++ ) t2= 0;   /* correct status optimized out? */
   if( ++t1 ) t2= 5;

}

   
_interupt(){
}
