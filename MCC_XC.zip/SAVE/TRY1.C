/* #include "\dsp\mc26lib\uart.h"  /* this causes problem */
/* #include "\dsp\mc26lib\tbuf.c"  /* this doesn't */

/* extern uart(); */

int _rrdy();

int val;


main(){
 int i,j;


 for( i= 3; i < j; ++i );

 }
