char *p;
/* try nested switch */
main(){
 int c;

 switch (c){
  case 2:
  c= 4;    break;
  case 4:
    switch(c){
      case 6:
        c= 1;
        break;
      case 8:
      break;
      }

   case 5:
   break;
   }

 }

