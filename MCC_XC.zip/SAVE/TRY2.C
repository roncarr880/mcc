#define ONE 1
#define ONE2 2

int dd[2][2]={ 10, 11, 20, 21 };

int  var[4]={ 1,{ 2} , 3, 4 };
int av={ 4 };
long cd;
static int b= 8;
char bear[]="this is a bear\r\n";
char *work="work";
char *names[]={"Fred","Bull","June"};
int *try[] = {2,4,6};
struct BIGTRY{
 int as;
 char *p;
 char name[10];
 } one  = { 4, bear, "Ron" } ; 

struct BIGTRY two[2]={ 10, "FRED", "Will",
                       20, bear, "Trespass" };

struct {
  int bit:4;
  int bit2:3;
  }bits;



main( c, p )
unsigned  c;
char p[]; 
{

 *p=   bear;

}

