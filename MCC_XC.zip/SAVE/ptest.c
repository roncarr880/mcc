

#include <pic16f84.h> 

char t1;
char t2;

main(){


   if( t1++ ) t2= 0;   /* correct status optimized out? */
   if( ++t1 ) t2= 5;

}

   
_interupt(){
}
