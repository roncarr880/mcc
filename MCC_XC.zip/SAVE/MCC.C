#define LINESIZE 255

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "mcsym.h"
#include "mcc.h"
#include "mcvar.h"
#include "mcout.h"

extern void statement();        


int dualtoken();
void blanks(int eolmode);        /* skip white space in file */
void nextline();                 /* preprocess next line */
void parse();                    /* 1st 2nd level parsing */
void openfile( char *filname );  /* recursive open input files */


/* globals */
FILE *fp;
char *lp;
char preword[LINESIZE];
char word[LINESIZE];
char line[LINESIZE];
int ccount, lcount;
int funactive;
int pflag;
int label;
char hash[5];


main( int count, char *files[]){

int i;
char *p;
extern int errcount;
extern unsigned int gaddress;

 gaddress= 0x0600;  /* set C26 page same as run time module */
 label= 1;
 for ( i= 1; i < count; i++ ){
    /* hash the name to use for static labels */
    p= files[i];
    hash[0]= hash[1]= hash[2] = 7;
    while( *p ){
       hash[0]^= *p;
       hash[1]= (char)((hash[0]+hash[1]) ^ *p);
       hash[2]= (char)((hash[1]+hash[2]) ^ *p++);
       }
    hash[0]= (char)(( hash[0] % 26 ) + 'A');
    hash[1]= (char)(( hash[1] % 26 ) + 'A');
    hash[2]= (char)(( hash[2] % 26 ) + 'A');
    hash[3]= 0;

    openfile( files[i] );
    }

    if( errcount ){
       printf("There were %d errors in compilation",errcount);
       exit( 1 );
       }

    dumpdata();
    dumpexterns();
    end();
}

     /* recursive open files */
void openfile( char *name ){

FILE *savefp;
char *savelp;
char temp[LINESIZE];
int saveccount, savelcount;
int savepflag;

  savelp= lp;      /* save globals as stack args */
  savefp= fp;
  strcpy(temp,line);
  saveccount= ccount;
  savelcount= lcount;
  savepflag= pflag;

  pflag= 0;
  if( (fp= fopen(name,"r")) != 0 ){
      lp= line;
      line[0]= 0;
      do{
 /*        next();  */
         parse();
         }while( lp );
      fclose( fp );
      }
   else{ 
      sprintf(temp,"Error opening %s", name);
      error(temp);
      }
   fp= savefp;
   lp= savelp;
   strcpy(line,temp);
   ccount= saveccount;
   lcount= savelcount;
   pflag= savepflag;
}   



int type(){   /* basic types - int variations( short long ) are separate */ 

  if( match("int") ) return INT;
  if( match("char") ) return CHAR;
  if( match("struct")) return STRUCT;
  if( match("void")) return VOID;
  if( match("union")) return UNION;

  return 0;
}

int scope(){
  if( match("extern") )return EXTERN;
  if( match("auto")) return AUTO;
  if( match("static")) return STATIC;
  if( match("register")) return AUTO;
  
  return 0;
}



void doasm(){
extern unsigned gaddress;
char *p, temp[40], *p2;
int hex;

  while( lp ){
     lp= fgets( line, LINESIZE, fp );
     ++lcount;
     if( strstr( lp ,"#endasm") != 0 ){
        *lp= 0;
        next();
        unnext();
        pilabel( label++ );      /* pilabel undefines arp and dp for c26 */
        return;
        }
  /* check for .ds directive and set the C26 page frame to same value */   
     p= strstr( line, ".ds" );     
     if( p ){
       p2= temp;
       p+= 3;   /* skip .ds */
       while( isspace( *p ) ) ++p;    /* skip space */
       while ( isspace( *p ) == 0  && *p ) *p2++ = *p++;  /* copy word */
       --p2;
       if( *p2 == 'h' ) hex= 1;    /* flag as hex value */
       else{
          hex= 0;
          ++p2;
          }
       *p2= 0;     /* terminate string - remove h on end if hex */
       if( hex ) sscanf(temp,"%x",&gaddress);
       else sscanf(temp,"%u",&gaddress);
       }

     
     outline( lp );
     }

}


void parse(){  
/* recursive parse all before statements levels */

struct SYMBOL sym;
int d;
char temp[40];
extern progdata;    
extern unsigned int gaddress;

     clear( &sym );   

     if( gofigure( &sym ) ){
     /*  complete the definition */
        if( sym.scope == 0 ){
           if( funactive ) sym.scope= AUTO;
           else sym.scope= GLOBAL;
           }
        if( sym.type == 0 ) sym.type= INT;
        if( sym.sign == 0 ) sym.sign= SIGNED;

        varlist( &sym, (struct OFFSET *) 0 );
        return;
        }

     next();   /* gofigure put it back */   
     
     if( match("#")){
        
        if( strncmp( lp,"asm", 3 ) == 0 ){  
           doasm();
           return;
           }

        next();
        if( match("include") ){
           if( *lp == '<' ){    /* may want to search special <dir> here */
              next(), next();
              strcpy( temp, word );
              if( *lp == '.' ){        /* get extension */
                 next(), strcat( temp, word ); 
                 next(), strcat( temp, word );
                 }
              }
           else{   /* should be an intact string */
              if( *lp != '"' ) error("Missing \"");
              next();
              strcpy ( temp, &word[1] ); /* chop leading " */
              d= strlen(temp);
              if( d ) temp[d-1]= 0;      /* chop ending " */
              }
           openfile(temp);
           if( *lp == '>' ) next();
           return;
           }

        if( match("define")){ 
           putmac();
           return;
           }

        if( match("pragma")){    /* compiler specific */
           next();
           if( match("text")){   /* put data in program space */
              progdata= 1;
              return;
              }
           if( match("data")){   /* put data in data space */
              progdata= 0;
              return;
              }
           if( match("pic")){  /* reassign gaddress for pic, from C26 init */
              next();
              gaddress= atoi( word );
              return;
              }
           }


        error("Unknown directive");
        }


     if( funactive ){        /* function active */
    /* parse all statements to end of function */
    /* allocate local storage */
        stackspace();

        csect();
        while( lp ){
           statement(); 
           if( *lp == '}' ) break;
           next();
           if( match("#") ){
              if( strncmp( lp,"asm",3 ) == 0){ 
                 doasm();
                 if( *lp == '}' ) break; 
                 next();
                 }
              else error("Directive in mid block");
              }
           }
        return;               /* end of function found */
        }
     
 /* looks like an error */      
     
     /* debug print things that are not parsed out */
     /* printf("Err %s",word);  */
     error("Syntax error");


}

    /* sort out the definition */
int gofigure( struct SYMBOL *sym ){
int d;
int status;

   status= 0;
   while( lp ){   /* get upcoming keywords if any */
      if( *lp == '*' ) break;
      if( *lp == '(' ) break;
      next();
            
      if( match("signed")){
         status= 1;
         if( sym->sign )error("Extra sign");
         sym->sign= SIGNED;
         continue;
         }

      if( match("unsigned")){
         status= 1;
         if( sym->sign )error("Extra sign");
         sym->sign= UNSIGNED;
         continue;
         }

      if( match("short")){
         status= 1;
         sym->type= INT;
         continue;
         }

      if( match("long")){
         status= 1;
         sym->type= LONG;
         continue;
         }

      if( d=scope() ){ 
         status= 1;
         sym->scope= d;
         continue;
         }

      if( d=type() ){
         status= 1;
         switch ( d ){
            case  CHAR:
              if( sym->sign == 0 ) sym->sign = UNSIGNED;
              sym->type= d;
              break;
            case INT:
              if( sym->sign == 0 ) sym->sign = SIGNED;
              if( sym->type != LONG ) sym->type= INT;
              break;
            default:
              sym->type=d;
            } /* end switch */
         break;        /* type keyword should be the end */
         }

     if( *lp == '(' && funactive == 0){   /* undeclared function */
        sym->type= INT;  /* default */
        status= 1;
        }

     /*  word must be the variable name - we went too far */ 
     unnext();
     break;  /* escape loop */    
     } /* end loop */


   return status;

}

#pragma trace-

void unnext(){
char temp[LINESIZE];

     /* put the word back */
     strcpy( temp, word );
     strcat( temp," " );
     strcat( temp, lp );
     strcpy( line,temp );
     lp= line;

}


void next(){   /* get next word, advance lp */
char *p;    
static int lastcount;

   ccount+= lastcount;

   if( pflag ) {
      comment( line );
      pflag= 0;
      }

   if( *lp == 0 ) nextline();
   if( lp ){ 
      p= word;

      if( *lp == '"' ) gslit( word );
      else if( *lp == '\'' ) gcc( word );
      else{
         while ( *lp != ' ' && *lp != 0 ){
            *p++ = *lp++;
            }
         *p= 0;
         }

      lastcount= strlen(word);
      while( *lp == ' ' ){ 
         ++lp;
         ++lastcount;
         }
      if( *lp == 0 && word[0] != '#') nextline();
      }
}


void nextline(){   /* preprocess next line */
char *p, *p2;   
char tokens[]="# \n~!%^&*()-+=[]{}|;:'\",.<>?/@$";
char templine[LINESIZE];

  blanks(0);            /* get new line */

  if( lp == 0 ) return; /* eof */

  templine[0] = 0;

  while ( *lp != '\n' ){
     if( *lp == '"' ) gslit( preword );
     else if( *lp == '\'' ) gcc( preword );

     else{               /* just normal words,  tokens */
        p= preword ;
        p2= strfind(lp,tokens);   /* look for word breaks */
        if( p2 == lp ){            /* token is next */
           ++p2;                   /* allow to get the token */
           p2+= dualtoken();       /* check for special tokens */
           }
        if( p2 ){
           while( lp != p2 ){     /* copy to word */
              *p++ = *lp++;
              }
           }
        *p= 0;
        }

     findmac();  /* make macro sub if any */
     strcat( templine, preword );
     strcat( templine," ");
     blanks(1);                 /* skip white space */
     }
  strcpy( line, templine );
  pflag= 1;   
  lp= line;
  ccount= 0;

}


int dualtoken(){   /* check for special character sequence in line */
int c;
  
  c= *(lp + 1);
  if( c == '=' ){ 
     c= *lp;
     if( c == '+' || c == '-' || c == '=' || c == '!' || c == '%' ||
         c == '^' || c == '&' || c == '*' || c == '|' || c == '/' || 
         c == '>' || c == '<' )
            return 1;
     }

  if( strncmp( lp,"<<=",3 ) == 0 ) return 2;
  if( strncmp( lp,">>=",3 ) == 0 ) return 2;
  if( strncmp( lp,">>",2 ) == 0 ) return 1;
  if( strncmp( lp,"<<",2 ) == 0 ) return 1;
  if( strncmp( lp,"->",2 ) == 0 ) return 1;
  if( strncmp( lp,"++",2 ) == 0 ) return 1;
  if( strncmp( lp,"--",2 ) == 0 ) return 1;
  if( strncmp( lp,"&&",2 ) == 0 ) return 1;
  if( strncmp( lp,"||",2 ) == 0 ) return 1;
  return 0;
}


void gslit( char *p ){   /* get string literal intact */

   *p++ = *lp++ ;
   while(1){
      if( *lp == 0 ){
         error("End of line in string");
         return;
         }
      if( *lp == '"' ) break;
      if( *lp == '\\' ){
        *p++ = *lp++;
        }
      *p++ = *lp++;
      }

   *p++ = *lp++;
   *p= 0;
}

void gcc( char *p ){   /* get character constant intact */
int c;

   c= 0;
   *p++ = *lp++;
   while( lp ){
     if( *lp == '\\' ){ 
        *p++ = *lp++;
        *p++ = *lp++;
        }
     else c= *p++ = *lp++;
     if( c == '\'' ) break;
     }

   *p= 0;
}





 /*  
    skip to next character of importance - eolmode does not skip
    to next line   
 */
void blanks(int eolmode){   /* skip spaces and end of lines */

  while(1){
     if( *lp == '\n' || *lp == 0 ){ 
        if( eolmode ) break;
        lp= fgets(line,LINESIZE,fp);
        lcount++;
        if( lp == 0 ) return;     /* eof */
        continue;
        }
     if( *lp == ' ' || *lp == '\t' ){ 
       ++lp;
       continue;
       }

   /* should skip comments in here also */
     if( *lp == '/' && *(lp+1) == '*' ){
         while( *lp != '*' || *(lp+1) != '/' ){ 
            if( *lp == '\n' ){ 
               if( eolmode ) break;
               lp= fgets(line,LINESIZE,fp);
               lcount++;
               if( lp == 0 ){ 
                  printf("Comment not complete at End of File");
                  return;
                  }
               continue;
               }
            ++lp;
            }
         lp+= 2;      /* skip comment end  */
         continue;
         }
     return;
     } /* end  - found a real character */
}


int match( char *p ){   /* see if p[] compares to global word */

 if( strcmp(word,p) == 0 ) return 1;
 return 0;
}

 /* maybe a bug in strpbrk, this attempts the same function of finding
    characters in a string */
char *strfind(char *p1, char *p2 ){
char *p;

  /* null cases */
  if( p1 == 0 || p2 == 0 ) return (char *) 0;
  while( *p1 ){
    p= p2;
    while( *p ){
       if( *p++ == *p1 ) return p1;
       }
    ++p1;   /* look at next in string */
    }
  return (char *) 0;
}


#pragma trace

void block(){       /* main parse of { to } before statements */

  mark();          /* mark symbol table */
  
  while( lp && *lp != '}' ){
     parse();
     }

  release();      /* clear any to last mark */

}


