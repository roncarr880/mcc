/* 
   8080 model hacked to 68HC11

   HL   arg pointer, primary register for ints and pointers
   A    primary register for char's
   BC   takes place of stack args
   DE   takes place of stack args
*/


#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "mcsym.h"
#include "mcout.h"
#include "mcc.h"
#include "mcvar.h"
#include "mcexp.h"


int c26= 0;  /* conditional executable for C26 code */
int progdata= 0; /* only for c26 */
int pic= 0;

int rtotal;   /* just needed for link */
int shortfun, shortcall;

/* output code dependant routines */

#define DSECT 1
#define CSECT 2

void loadhlvia();


int jumpval;

int  flags;              /* valid status flags? */
static section;
extern char hash[];
int loadoffset;      /* for call stack offset on loads */

/* stack optimization */
/* 
   routines must call check(HL) or check(A) 
   before using the HL or A registers 
*/
void check( int what );
void mypush( int size );
void mypop( struct EVAL *e1);


#define A 4
#define HL 2
#define BC 1       /* match offsets of fargs and auto for bc and de */
#define DE 3
#define SA 5
#define SHL 6
#define STACKSIZE 15


static int stack[STACKSIZE+1];

static int arg; /* function call offset */



void pushadd(){       /* for c26 compat */
}

void popadd(){
}


void preg( int off ){
  if( off > 8 )error("Too many locals");
  printf("%d,X",off+2);
/******
 switch( off ){
   case 0: printf("c"); break;
   case 1: printf("b"); break;
   case 2: printf("e"); break;
   case 3: printf("d"); break;
   default: error("Too many locals - use statics"); 
   }   ****** */
}

void prefun(){

 check(A);
 check(HL);
 printf("\tPSHX\t  *;_CALL\n");
 printf("\tXGDX\n");
 printf("\tSUBD\t#10\n");
 printf("\tXGDX\n");
/* printf("\tpush\td\n");*/
 arg= 0;  loadoffset = 10;

}

void postfun(){

/*  printf("\tpop\td\n"); */
  printf("\tPULX\n");
  flags= 1;                /* functions always gen status */

}

void callfun( struct EVAL *e1 ){
char *p;

 
 if( e1->type == VALUE ){
    printf("\thlpc\n");
    }
 else{
    if( e1->type == FOUND ) p= findname( &e1->var );
    else{ 
       p= &e1->var.name;
       e1->var.type= CHAR;  /* change default from int */
       }

    printf("\tJSR\t%s\n", p );
    }

 loadoffset = 0;
}


void storearg( struct EVAL *e1 ){

 /* avoid moves to self */
/* debug code only ----------- */
/* printf("scope %d  offset %d  type %d  ident %d\n",
    e1->var.scope,e1->var.offset,e1->var.type,e1->var.ident); */
/*----------------------------- */
/* this was causing problems, fixed the constants
but still have problem with expressions with a suppressed var
ie call( creg + 2 );   T80 fixes most of extra loads
 if( ( e1->var.scope == FARG || e1->var.scope == AUTO ) &&
      e1->var.offset == arg && e1->type != CONSTANT ){
    if( e1->var.type == CHAR && e1->var.ident == VAR ) ++arg;
    else arg+= 2;
    return;
    }
 */


 loadval( e1 );

 if( arg + e1->datasize  > 9 ){
    error("Exceeded local storage framesize");
    }


 if( e1->datasize == 1 ){

    printf("\tSTAB\t%d,X\n",arg+2);
 /*****
    switch( arg ){
       case 0:  printf("\tmov\tc,a\n"); break;
       case 1:  printf("\tmov\tb,a\n"); break;
       case 2:  printf("\tmov\te,a\n"); break;
       case 3:  printf("\tmov\td,a\n"); break;
       }
 ******/
    ++arg;
    }
 else{
    if( e1->var.ident == POINTER || e1->var.ident == ARRAY )
         printf("\tSTY\t%d,X\n",arg+2);
    else printf("\tSTD\t%d,X\n",arg+2);

  /****
    switch( arg ){
       case 0: printf("\tmov\tc,l\n\tmov\tb,h\n");  break;
       case 2: printf("\tmov\te,l\n\tmov\td,h\n");  break;
       default: error("Not integer boundary");  break;
       }
  *****/
    arg+= 2;
    }
}


void pinport( struct EVAL *e1 ){

  if( e1->type != CONSTANT ) error("Expected constant");
  printf("\tin\t%d\n",e1->val);
}


void poutport( struct EVAL *e1 ){
  
  if( e1->type != CONSTANT ) error("Expected constant");
  printf("\tout\t%d\n",e1->val);
}


int loadlit( char *p ){   /* load val for string literal */

   check(HL);
   printf("\tlxi\th,%s\n",p);
   return(HL);
}


void preturn(){
extern int last_ret;  

  if( last_ret == 0 ) printf("\tRTS\n");

}


void check(int reg){
int i,j;


   for( i= 0; i < STACKSIZE; i++ ) if( stack[i] == reg ) break;
   if( i == STACKSIZE ) return;

   /* really push the value and all above it */

   for( j= STACKSIZE; j >= i;  j--){
      if( stack[j] == A ){
         printf("\tpush\tpsw\n");
         stack[j]= SA;
         }
      if( stack[j] == HL ){
         printf("\tpush\th\n");
         stack[j]= SHL;
         }
      if( stack[j] == BC ){
         printf("\tpush\tb\n");
         stack[j]= SHL;         /* reg vars always popped to HL */
         }
      if( stack[j] == DE ){
         printf("\tpush\td\n");
         stack[j]= SHL;
         }
      }

}   


void mypush( int size ){
int i;

  if( stack[STACKSIZE] != 0 ) error("Mystack overflow");

  for( i= STACKSIZE ; i > 0 ; i-- ) stack[i]= stack[i-1];
  stack[0]= size;

}


void mypop(struct EVAL *e1){
int i;

   if( stack[0] == SA ) printf("\tpop\tpsw\n");
   if( stack[0] == SHL ){ 
      printf("\tpop\th\n");
      e1->reg= HL;
      }
   /* all other regs are on stack as SHL */
   for( i= 0; i < STACKSIZE; i++) stack[i]= stack[i+1];

}


void cast( struct EVAL *e1, size ){

 if( e1->datasize == size ) return;  /* not needed */

 if( e1->type == VALUE ) {    /* only need to move loaded values */
    if( size == 2 && e1->datasize == 1 ){
       check(HL);
       printf("\tCLRA\t\t*cast\n");
     /*  printf("\tXGDY\n"); */
       }
    else if( size == 1 && e1->datasize == 2 ){
       check(A);
     /*  printf("\tXGDY\t*cast\n"); */
       printf("\tCLRA\t\t*cast\n");
       }
    /* else it may be some other size not supported */
    }

 if( e1->type == SECVAL ){     /* clear high byte */
    if( size == 2 && e1->datasize == 1 ) printf("\tmvi\td,0\n");
    }

 e1->datasize= size;   

}


void doubleval( struct EVAL *e1 ){
/* this version supports only 8 and 16 bit values */

  if( e1->datasize == 1 ) printf("\tadd\ta\n");
  else if( e1->datasize == 2 ) printf("\tdad\th\n");
  else error("Unsupported size");


}



void incdecm( int op ){

   if( op == '+' ) printf("\tINC\t0,Y\n");
   else printf("\tDEC\t0,Y\n");
}

void incdechl( int op ){
   
   check(HL);
   if( op == '+' ) printf("\tinx\th\n");
   else printf("\tdcx\th\n");
}

void incdecreg( int op, int off, size ){
  
   switch ( size ){
      case 1:
      if( op == '+' ) printf("\tINC\t");
      else printf("\tDEC\t");
      break;

      case 2:
      check(off);  /* check if BC or DE need a push */
      if( op == '+' ) printf("\tINC\t");
      else printf("\tDEC\t");
      break;
      }
  preg( off );
  nl();
}


void preincdec( struct EVAL *e1, int op ){

switch( e1->var.ident ){
   case VAR:
   switch( e1->var.type ){
      case CHAR:
      flags= 1;
      if( e1->var.scope == FARG || e1->var.scope == AUTO ){
         incdecreg( op, e1->var.offset, 1 );
         }
      else{
         address( e1 );
         incdecm( op );
         }
      break;
                     
      case INT:
      default:    /* assume int var size  for any others */
      if( e1->var.scope == FARG || e1->var.scope == AUTO ){
         incdecreg( op, e1->var.offset, 2 );
         }
      else{
         loadval( e1 );
         incdechl( op );
         store( e1,0 );
         }
      break;
            
      }  /* end var.type */
      break;

   case POINTER:
   /* get size of whats pointed to */
   /* assume just simple vars for now */
   if( e1->var.scope == FARG || e1->var.scope == AUTO ){
      incdecreg( op, e1->var.offset, 2 );
      if( e1->var.type != CHAR ) incdecreg( op, e1->var.offset, 2 );
      }
   else{
      loadval( e1 );
      incdechl( op );
      if( e1->var.type != CHAR ) incdechl( op );
      store( e1,0 );
      }
   break;

   default:  error("Can't inc-dec this type"); break;

   }   /* end var.ident */
 

}





void postincdec( struct EVAL *e1, int op ){

switch( e1->var.ident ){
   case VAR:
   switch( e1->var.type ){
      case CHAR:
      if( e1->var.scope == FARG || e1->var.scope == AUTO ){
         loadval( e1 );
         incdecreg( op, e1->var.offset, 1 );
         }
      else{
         address( e1 );
         loadval( e1 );
         incdecm( op );
         }
      break;
                     
      case INT:
      default:    /* assume int var size */
      if( e1->var.scope == FARG || e1->var.scope == AUTO ){
         loadval( e1 );
         push( e1 );
         incdecreg( op, e1->var.offset, 2 );
    /*     pop( e1 );   */
         }
      else{
         loadval( e1 );
         push(e1);
         incdechl( op );
         store( e1,0 );
         pop(e1);
         }
      break;
            
      }  /* end var.type */
      break;

   case POINTER:
   /* get size of whats pointed to */
   /* assume just simple vars for now */

   if( e1->var.scope == FARG || e1->var.scope == AUTO ){
      loadadd( e1 );
      push( e1 );
      incdecreg( op, e1->var.offset, 2 );
      if( e1->var.type != CHAR ) incdecreg( op, e1->var.offset, 2 );
  /*    pop( e1 );   */
      }
   else{
      loadadd( e1 );
      e1->type= ADDRESS;     /* fake out push */
      push( e1 );
      e1->type= VALUE;       /* call value for store */
      incdechl( op );
      if( e1->var.type != CHAR ) incdechl( op );
      store( e1,0 );
      pop( e1 );             /* want it to remain value for now */
      }
   break;

   default:  error("Can't inc-dec this type"); break;

   }   /* end var.ident */
 
}


void negate(){
   compliment();
   printf("\tADDD\t#1\n");
}

void compliment(){
   printf("\tcOMa\n");
   printf("\tCOMB\n");
}


void cpi( long val ){   /* compare immediate */
   printf("\tcpi\t%d\n",(int)val);
   flags= 1;
}


void  status(struct EVAL * e1){        /* generate flag status */
   
   if( flags == 0 ){ 
      loadval(e1);
    /*  printf("\tora\ta\n");  */
      }
   flags= 1;
}


void storei( struct EVAL *e1 ){
char *p;

 /* assume int type */
  switch( e1->var.scope ){
     case FARG:
     case AUTO:
     /**************
        if( e1->var.offset == 0 ){
           printf("\tmov\tc,l\n");
           printf("\tmov\tb,h\n");
           }
        else{
           printf("\tmov\te,l\n");
           printf("\tmov\td,h\n");
           }
    ******************/
        printf("\tSTD\t%d,X\n",e1->var.offset+2);  
        break;

     case STATIC:
     case GLOBAL:
     case EXTERN:
        p= findname(&e1->var);
        printf("\tSTD\t%s",p);
               if( e1->val ) printf("+%d",e1->val);
               nl();
        break;
     }
     e1->type= VALUE;
}


void store( struct EVAL * e1, int reg ){
char *p;

   if( e1->var.type != CHAR || 
      ( e1->var.type == CHAR &&  e1->var.ident == POINTER &&
        e1->var.indirect != 0 ) ) {
        storei( e1 );
        return;
        }

   /* rest is for chars */

   switch( e1->type ){
      case VALUE:   
      case CONSTANT: error("can't store to that"); break;
      case TEMPVAL:
      case STACKVAL:
      case STACKADD:
         pop( e1 );         /* nobreak */
      case ADDRESS: 
         switch( e1->reg ){
           case HL: printf("\tSTAB\t0,Y\n");  break;
           case BC: printf("\tstax\tb\n"); break;
           case DE: printf("\tstax\td\n"); break;
           }
         break;
      case FOUND:
         switch( e1->var.scope ){
            case GLOBAL:
            case STATIC:
            case EXTERN:
               p= findname( &e1->var );
               printf("\tSTAB\t%s",p);
               if( e1->val ) printf("+%d",e1->val);
               nl();
               break;
            case FARG:
            case AUTO:
               if(e1->var.offset > 8) error("Too many locals");
               printf("\tSTAB\t");
               printf("%d",e1->var.offset+2);
               printf(",X\n");
               break;
            }
      /*   break; */
      } /* end switch type */
   /* think want to say its has value now even though its probably address */
   e1->type= VALUE;
}


void tempval( struct EVAL * e1 ){   /* store value on stack */

    if( e1->type == CONSTANT ) return;  /* don't need to store constant */
    loadval( e1 );
    push( e1 );
}


void push( struct EVAL * e1){


    if( e1->datasize == 1  ){
       mypush( A );   /*  printf("\tpush\tpsw\n");   */
       }
    else mypush( e1->reg );  /* printf("\tpush\th\n"); */

    if( e1->type == VALUE ) e1->type= STACKVAL; 
}

void pop(struct EVAL *e1 ){

  mypop( e1);
  if( e1->type == STACKVAL ) e1->type= VALUE;
}




void loadval( struct EVAL * e1 ){
char *p;   
int mysize, save;


  mysize= e1->datasize;
  switch( e1->type ){
     case VALUE:             
     case FUNCALL:
        break;

     case STACKVAL:
        pop(e1);
        break;
     case CONSTANT:
     if( e1->val > 255 || e1->val < -128 ){  /* int size */
         check(HL); mysize= SOINT;
         printf("\tLDD\t#%d\n",e1->val);
         }
     else{
        check(A);  mysize= SOCHAR;
        printf("\tLDAB\t#%d\n",e1->val);
        }
        break;
     case STACKADD:  pop( e1 );  /* nobreak */
     case ADDRESS:
        if( e1->var.ident == VAR && e1->var.type == CHAR ){ 
           check(A);  mysize= SOCHAR;
           switch( e1->reg ){
              case HL: printf("\tLDAB\t0,Y\n"); break;
              case BC: printf("\tldax\tb\n"); break;
              case DE: printf("\tldax\td\n"); break;
              }
           }
        else{ 
           loadhlvia();
           mysize= SOINT;
           }
        break;
     case FOUND:
        switch( e1->var.scope ){
           case GLOBAL:
           case STATIC:
           case EXTERN:
              p= findname( &e1->var );
              if( e1->var.type == CHAR && e1->var.ident == VAR ){
                 check(A);  mysize= SOCHAR;
                 printf("\tLDAB\t%s",p);
                 if( e1->val ) printf("+%d",e1->val );
                 nl();
                 }
              else if( e1->var.ident == ARRAY ){ 
                 address( e1 );
                 mysize= SOP;
                 }
              else{ 
                 check(HL); mysize= SOINT;
                 printf("\tLDD\t%s",p );
                 if(e1->val) printf("+%d",e1->val);
                 nl();
                 }
              break;
           case FARG:
           case AUTO:
              if( e1->var.ident == VAR && e1->var.type == CHAR ){
                 check(A); mysize= SOCHAR;
                 printf("\tLDAB\t%d,X",e1->var.offset+2+loadoffset);
               /*  preg( e1->var.offset ); */
                 nl();
                 }
              else if( e1->var.ident == ARRAY ) 
                    error("Register can't be array");
              else{ 
                 check(HL);
                 printf("\tLDD\t%d,X",e1->var.offset+2+loadoffset);
               /*  preg( e1->var.offset ); */
                 nl();
              /*  **** printf("\tmov\th,");  
                 preg(e1->var.offset);
                 nl();****  */
                 mysize= SOINT;   
                 }
              break;
           } /* end scope */
           break;

     }  /* end switch type */

  e1->type = VALUE;
  flags= 0;

  if( e1->datasize == 0 ) e1->datasize= mysize;
  else if( mysize != e1->datasize ){  /* gen cast code */
     save= e1->datasize;
     e1->datasize = mysize;      /* set to size actual loaded */
     cast( e1, save );           /* and change it back */
     }

}

     
/* loadadd - much same as loadval except can use other than primary reg */
void loadadd( struct EVAL * e1 ){
char *p;

 switch(e1->type ) {
   case FOUND:
   switch( e1->var.scope ){
      case AUTO:
      case FARG:
      e1->reg= e1->var.offset + 1; /* just say its in a register */
      break;

      default:   /* globals etc.. */
      check(HL); 
      p= findname( &e1->var );
      printf("\tlhld\t%s\n",p);
      e1->reg= HL;
      break;
      }
   break;

   case STACKADD:
   case STACKVAL:
      pop( e1 );      /* no break */
   case ADDRESS:
   case VALUE:
      switch( e1->reg ){
         case HL:  loadhlvia(); break;

         case BC:
         case DE:   
         check(HL);
         printf("\tpush\t");  preg( e1->reg ); nl();
         printf("\tpop\th\n");
         loadhlvia();
         break;
         }
   break;
   }   
 
 e1->type= VALUE;
}


     
     
void loadhlvia() {     /* load HL via HL */

check(HL);      /* in case we want to save the address */
printf("\tpush\td\n");

  printf("\tmov\te,m\n");
  printf("\tinx\th\n");
  printf("\tmov\td,m\n");
  printf("\txchg\n");

printf("\tpop\td\n");     

}

void storesvia(){     /* store stack via HL */
  printf("\txchg\n");
  printf("\txthl\n");
  printf("\txchg\n");
  printf("\tmov\tm,e\n");
  printf("\tinx\th\n");
  printf("\tmov\tm,d\n");
  printf("\tpop\td\n"); 
}



void address( struct EVAL * e1 ){
char *p;

  if( e1->type == ADDRESS ) return;

  check(HL);
  switch( e1->var.scope ){
     case FARG:
     case AUTO:
        error("Can't form address of register");
        break;

     case STATIC:
     case GLOBAL:
     case EXTERN:
        p= findname( &e1->var );
        printf("\tLDY\t#%s",p);
        if( e1->val ) printf("+%d",e1->val);
        nl();
        break;

     }
  e1->type= ADDRESS;
  e1->reg= HL;
}



void secval( struct EVAL * e1 ){

if( e1->type == SECVAL ) return;
switch (e1->datasize){
   case 0:   /* unknown assume char in this case */
   case 1:

   if( e1->type == FUNCALL ) e1->type = VALUE;

   /* constants and address loaded do not need data loaded */
   if( e1->type == CONSTANT ) return;
   if( e1->type == FOUND ){
      if( e1->var.scope == FARG || e1->var.scope == AUTO ){
         e1->type= REGVAL;
         return;
         }
      else { 
         address( e1 );
         return;
         }
      }
   if( e1->type == ADDRESS ){ 
      if( e1->reg == HL )return;
      else{
         check(HL);
         printf("\tmov\tl,");
         preg( e1->reg -1);   nl();
         printf("\tmov\th,");
         preg( e1->reg );   nl();
         e1->reg= HL;
         return;
         }
      }
   if( e1->type == VALUE ) printf("\tmov\th,a\n");
      
   if( e1->type == STACKVAL ){ 
      pop( e1 );
      printf("\tmov\th,a\n");
      }
   break;

   case 2:
/*   printf("\tpush\td\n"); */
   switch( e1->type ){
      case CONSTANT: printf("\tlxi\td,%d\n",( int ) e1->val); 
      break;

      case STACKVAL: printf("\txchg\n");  
      pop( e1 );  
      printf("\txthl\n");  /* no break */
      case VALUE : printf("\txchg\n");  
      break;

      case FOUND:   
      switch( e1->var.scope ){
         case STATIC:
         case GLOBAL:
         case EXTERN:  loadval( e1 );  /*printf("\txchg\n");*/
         break;
         
         default:      /* auto and farg */
         printf("\tmov\te,"); 
         preg(e1->var.offset);
         nl();
         if( e1->var.ident == VAR && e1->var.type == CHAR ){   /* was cast */
            printf("\tmvi\td,0\n");
            }
         else{
            printf("\tmov\td,");
            preg(e1->var.offset);
            nl();
            }
         break;
         }
      break;

      case ADDRESS: 
      printf("\tmov\te,m\n"); 
      if( e1->var.ident == VAR && e1->var.type == CHAR ){  /* was cast */
         printf("\tmvi\td,0\n");
         }
      else{
         printf("\tinx\th\n"); 
         printf("\tmov\td,m\n");  
         }
      break;
      }
   break;  /* case size 2 */

   default: error("Type not supported");
   }
e1->type= SECVAL;
  
}


void doopstore( struct EVAL * e1, struct EVAL * e2, int op ){
}



void doop( struct EVAL * e1, struct EVAL * e2, int op ){
int mask;
int count;

   if( e1->datasize > e2->datasize ) cast( e2, e1->datasize );
   else if( e2->datasize > e1->datasize ) cast( e1, e2->datasize);
   
   secval( e2 );
   loadval( e1 );

if( e1->datasize < 2 ){           /* char code */
   mask= 0;
   if( e2->type == CONSTANT ){
      switch( op ){
         case '+': printf("\tADDB"); break;
         case '-': printf("\tSUBB"); break;
         case '&': printf("\tANDB"); break;
         case '|': printf("\tORAB"); break;
         case '^': printf("\tEORB"); break;
         /* shifts are constant only for 8080 */
         case '>':
            mask= 255;
            if( ( count= (int) e2->val ) > 7 )  printf("\txra\ta");
            else{
                while( count-- ){ 
                   printf("\trrc\n");
                   mask >>= 1;
                   }
                printf("\tani\t%d\n",mask);
                }
            break;
         case '<':
            mask= 255;
            if( ( count= (int) e2->val ) > 7 )  printf("\txra\ta");
            else{
                while( count-- ){ 
                   printf("\trlc\n");
                   mask <<= 1;
                   }
                printf("\tani\t%d\n",mask & 255);
                }
            break;
            
         default: error("Not supported");    /*   * / %   */
         }
      if( mask == 0 ) printf("\t#%d\n",( int )e2->val);
      }

   else{       /* not immediate op */
      switch( op ){
         case '+': printf("\taddB\t"); break;
         case '-': printf("\tsubB\t"); break;
         case '&': printf("\tandB\t"); break;
         case '|': printf("\toraB\t"); break;
         case '^': printf("\tEORB\t"); break;
         default: error("(* / %) Not supported");    /*   * / %   */
         }
      
      if( e2->type == ADDRESS ) printf("0,Y\n");
      else if( e2->type == REGVAL ){
         preg( e2->var.offset );
         nl();
         }
      else printf("h\n");    /* secval assumed */           
      }

   flags= 1;
   }

else if( e1->datasize == 2 ) {  /* int and pointer code */
   switch(op){
      case '+':  printf("\tABY\n"); break; /* was dad d */
      default: error("Only add supported");
      }
   flags= 0;
 /*  printf("\tpop\td\n"); */
   e1->reg= HL;
   }  /* end int code */


}







void compare( struct EVAL * e1, struct EVAL * e2 ){
struct EVAL * temp;
int swap;

/* 8080 can not easily do JLE and JG so swap for these */
   swap= 0;
   if( jumpval == JLE || jumpval == JG ){
      swap= 1;
      temp= e1;   e1= e2;   e2= temp;     /* swap pointers and jump type */
      if( jumpval == JG ) jumpval= JL;
      else jumpval= JGE;
      }

   secval( e2 );
   loadval( e1 );
   switch( e2->type ){
      case CONSTANT:
         printf("\tCMPB\t#%d\n",e2->val);
         break;
      case ADDRESS:
         printf("\tCMPB\t0,Y\n");
         break;
      
      case REGVAL:
         printf("\tcmpB\t");
         preg( e2->var.offset );
         nl();
         break;
      case SECVAL:
         printf("\tcmp\th\n");
         break;
      default:
         error("Unknown type");
      }

   flags= 1;
/* say e1 is loaded even if it wasn't, if there was a swap */
   if( swap ) e2->type = VALUE;   /* e2 is really e1 */
}



void pad( int count ){   /* output DB to fill in array */
int i;

  if( count <= 0 ) return;
  while( count ){
     printf("\tDB ");
     for( i= 0; i < 10 ; i++ ){
        printf("0");
        --count;
        if( count && i < 9 ) printf(",");
        if( count == 0 ) break;
        }
     printf("\n");
     }
}

void dw( char *p ){      /* output string as data word */
   printf("\tDW %s\n",p);
}



/* output literal as series of bytes terminated in a zero */
int outlit( char *p ){  
int count;
int i, c;  

  i= strlen( p );     /* get rid of the "" */
  if( i ){ 
     p[i-1]= 0;
     ++p;
     }
  count= 0;
  while( *p ){
     printf("\tDB ");
     for( i= 0; i < 10 ; i++ ){
        c= *p;
        if( c == '\\' ){
           c= *++p;
           switch( tolower(c) ){
              case 't': c= '\t'; break;
              case 'r': c= '\r'; break;
              case '\\': c= '\\'; break; 
              case '\'': c= '\''; break;
              case 'n': c= '\n'; break;
              case 'a': c= '\a'; break;
              case 'b': c= '\b'; break;
              case 'f': c= '\f'; break;
              case 'v': c= '\v'; break;
              }
         }
         printf("%d",c);
         ++count;
         if( c == 0 ) break;
         if( i < 9 )printf(",");
         ++p;
         }
     printf("\n");
     }
  if( c != 0 ) printf("\tDB 0\n");
  return count;
}

void dbytes( long val, int size ){ /* output as list of DB's lsb to msb */
long div= 1;   
long i;

   printf("\tDB ");
   while( size ){
      i= (val/div) % 256;
      printf("%ld",i);
      val-= i;
      div*= 256;
      if( --size ) printf(",");
      }
   nl();
}



void comment( char *p ){  /* print as comment */

  printf("* %s\n",p);
}


void dsect(){  /* output to data section */

   if( section != DSECT ){ 
      printf("* : DSECT\n");
      section= DSECT;
      }
}

void csect(){ /* output to code section */
   if( section != CSECT ){ 
      printf("* : CSECT\n");
      section= CSECT;
      }
}

void nl(){           /* new output line */
   printf("\n");
}

void plabel( char *p ){    /* print a label */
extern int last_ret;
   last_ret = 0;
   printf("%s:",p);
}

void pilabel( int num ){   /* print a label from number */
extern int last_ret;
   last_ret= 0;
   printf("%s%d:\n",hash,num);
}


void ds( int size ){       /* print a Date Space directive */
   printf("\tBSZ %d\n",size);

}

void jump( int lab){             /* jump */

   if( jumpval != ALWAYS ){   /* gen status flags for jump */
      if( flags == 0 ){
         printf("\tSTAB\t0,X\n");
         printf("\toraB\t0,X\n");
         flags= 1;
         }
      }

   switch( jumpval ){
      case JE:   printf("\tBEQ");   break;
      case JNE:  printf("\tBNE");  break;
      case JL:   printf("\tBLO");   break;
      case JGE:  printf("\tBGE");  break;
      case ALWAYS:  printf("\tJMP");  break;
      /* not used - compare swaps for another */
      case JLE:   printf("\tBLS"); break;   /* jc label, jz label */
      case JG:    printf("\tBHI"); break;   /* jc no, jz no, jmp label, no: */
           error("Internal code error - jump");
      }

   printf("\t%s%d\n",hash,lab);
   flags= 0;
}


void outline( char *p ){  /* just print out the line */

  printf("%s",p);

}

void pjump( char *p ){  /* print jump to label, used by goto */

  printf("\tjmp\t%s\n", p);
}


void pextern( char *p ) {

  printf("\textrn\t%s\n", p);
}

void end(){

   printf("\n*;end\n");
}


void dumpdata(){

   printf("globals:\n*;DSECT\n");

}

void center(char *p){
  plabel( p );
  nl();
}

void rel( int d ){

}

void stackspace(){

}

void stackvar( int size ){

}

void pointeradd( struct EVAL *e1, struct EVAL *e2, int op ){
struct SYMBOL one;
struct EVAL e3;
int s;

 /* just regular if both are pointers */
 if( (e2->var.ident == POINTER || e2->var.ident == ARRAY) &&
    ( e2->type != CONSTANT ) ){
    doop( e1, e2, op );
    return;
    }

 /* adjust size of e2 according to e1 parameters */
 copysymbol( &one, &e1->var );
 if( one.ident == ARRAY ){
    if( one.size2 ){       /* double arrary */
       one.size2= 0;
       s= size( &one );
       }
    else s= sizeone( &one );
    }
 else{        /* its a pointer */
    one.ident= VAR;
    s= size( &one );
    }


 if( e2->type == CONSTANT ) e2->val *= (long)s;
 else if( s == 1 ) ;   /* don't need to adjust */
 else{
    loadval( e2 );
    switch( s ){
       case 2:             /* double the value */
       doubleval( e2 );
       break;

       case 4:  doubleval( e2 );  doubleval( e2 ); break;

       default:             /* need to multiply */
       e3.type= CONSTANT;
       e3.val= (long) s;
       doop( e2, & e3, '*' );
       break;
       }
   }

 /* now do the original operation */

 /* optimize constants - no code generated yet */
 if( e1->type == FOUND && e2->type == CONSTANT  &&
       ( e1->var.scope == STATIC || e1->var.scope == GLOBAL ||
       e1->var.scope == EXTERN )  && e1->var.ident == ARRAY )
       e1->val += e2->val;
 else{
    /* set size before calling doop */
    if( e1->datasize == 0 ) e1->datasize = SOP;
    doop( e1, e2, op );
    }

}
