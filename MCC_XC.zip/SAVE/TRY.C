


/* see if can make address of a function */

void try();

 void ( * p)();


main(){
/* void ( * p)(); */
char a;

  p= & try;
  (*p)();

}

void try(){

 puts("it works");

}
