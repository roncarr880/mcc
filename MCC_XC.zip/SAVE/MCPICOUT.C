/* 
   pic 16f84 from the tms320c26 model
*/


#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include "mcsym.h"
#include "mcout.h"
#include "mcc.h"
#include "mcvar.h"
#include "mcexp.h"


/* global flags for conditional executable - instead of using 
   conditional compilation - avoids need recompile when changing
   output module   */

int c26= 0;       /* changes char to int size for c26 */
int pic= 1;
int eeadr= 0;
int eedata[100];



char stg[100];


extern void flush( int num );   /* flush the output buffer */
extern void stage( char *p );   /* stage write to output */

/* output code dependant routines */

#define DSECT 1
#define CSECT 2

void pointeradd( struct EVAL *e1, struct EVAL *e2, int op );
void loadhlvia();
void larp( int val );
void ldpk( struct EVAL *e );
int nextarp();


int arp; 
int dp;
int oldoff;     /* not needed ?,stack offset */
int totalsize;
int narp= 2;
char funarg[40];    /* for the one function argument */

int jumpval;

int  flags;              /* valid status flags? */
static section;
extern char hash[];
extern char history[];

/* flags for interupt function - these have leading underscores */

int shortcall, shortfun;
int progdata;     /* flag if we are compiling data to program space */


int stackcount;    /* detect two pushes in a row */



/* try to convert e->reg to these */

#define W 0      /* in W */
#define FSR 2    /* indirect, AR2 etc */
#define ARG 1    /* local function arg,stackarg, replace AR1 */
#define EEADR 3  /* eeprom */

/* old definitions */

#define A 4
#define HL 2
#define BC 1
#define DE 3
#define SA 5
#define SHL 6

#define AR0 0
#define AR1 1
#define AR2 2
#define AR3 3
#define AR4 4
#define AR5 5
#define AR6 6
#define AR7 7


static int arg; /* function call offset */



void check( int val ){   /* check on push count before using W register */

    if( stackcount > val ){
       flush(ALL);
       error("chk:Expression is too complicated");
       }

}

#if 0
void preg( int off ){ /* access local stack variables, probably not needed */
int val;

  off= off/2;    /* fudge offset for now */

   oldoff= off;


}
#endif

void prefun(){

  if( stackcount > 0 ){
     flush(ALL);
     error("Put function call first in the expression");
     }

}

void postfun(){

  dp= -1;                  /* page and arp may have changed */
  flags= 0;                /* functions may not gen status */
  shortcall= 0;            /* clear flag */

}

void dump( struct EVAL *e1 ) {  /* debug, print out all */
   flush(ALL);
   printf("type\t%d\n",e1->type);
   printf("reg\t%d\n",e1->reg);
   printf("val\t%d\n",e1->val);

   printf("var\n");
   printf("name\t%s\n",e1->var.name);
   printf("scope\t%d\n",e1->var.scope);
   printf("ident\t%d\n",e1->var.ident);
   printf("type\t%d\n",e1->var.type);
   printf("indirect\t%d\n",e1->var.indirect);
   printf("offset\t%d\n",e1->var.offset);
   printf("address\t%d\n",e1->var.address);


}


void callfun( struct EVAL *e1 ){
char *p;

                    /* function pointer */
 if( e1->type == VALUE ){  /* no guarantee this will work */
    p= &e1->var.name;
    sprintf(stg,"\tmovf\t%s + 1,W\n",p);  stage(stg);
    stage("\tmovwf\tPCLATH\n");
    sprintf(stg,"\tmovf\t%s,W\n",p);   stage(stg);
    stage("\tmovwf\tPCL\n");
    }
 else{
    if( e1->type == FOUND ) p= findname( &e1->var );
    else{ 
       p= &e1->var.name;
       e1->var.type= INT;  /* change default from int */
       }

    sprintf(stg,"\tcall\t%s\n", p );
    stage(stg);
    }

 flush(ALL);
 arg= 0;     /* reset arg count for next call */

}


void storearg( struct EVAL *e1 ){

 if( e1->type != VALUE ) loadval( e1 );  /* pass in W reg */

 if( shortcall ){     /* interupt can't have an argument */
    flush(ALL);
    error("Interupt function can not have an argument");
    }
 
 arg+= 1;   /* e1->datasize is two for some reason */
 if( arg > 1 ) error("Only one char argument allowed");
}


void pinport( struct EVAL *e1 ){

  if( e1->type != CONSTANT ) error("Expected constant");

/* no in or out instructions  @ or $ */
}


void poutport( struct EVAL *e1 ){
  
  if( e1->type != CONSTANT ) error("Expected constant");

}


int loadlit( char *p ){   /* load val for string literal */
int reg;

   error("No code for string literals yet");

}


void preturn(){
extern int last_ret;  

  if( last_ret == 0 ){ 
     if( shortfun ) stage("\tretfie\n");
     else stage("\treturn\n");
     }
  last_ret= 0;
  flush(ALL);
}




void cast( struct EVAL *e1, size ){

 if( size != 1 )error("Unsupported data size");
 e1->datasize= size;   

}



void incdeca(struct EVAL *e1, int op ){
char *p;
               /* inc dec simple vars */
               /* pointers/arrays must be resolved */

   if( e1->var.scope == EXTERN ) error("No inc/dec for eeprom data");
   p= findname( &e1->var );
   if( e1->var.scope == FARG ) p = funarg;
    
   if( op == '+' ) stage("\tincf\t");
   else stage("\tdecf\t");
   if(e1->reg != FSR ) sprintf(stg,"%s,F\n",p);
   else sprintf(stg,"INDF,F\n");
   stage(stg);

}

void incdecar( struct EVAL * e1, int op ){
char *p;      

  
   if( e1->var.scope == EXTERN ) error("No inc/dec for eeprom data");
   p= findname( &e1->var );        /* inc/dec the pointer name */
   if( e1->var.scope == FARG ) p = funarg;

   if( op == '+' ) stage("\tincf\t");
   else stage("\tdecf\t");
   sprintf(stg,"%s,F\n",p);
   stage(stg);

}



void preincdec( struct EVAL *e1, int op ){
int temp,reg;
/* int siz; */
struct EVAL e2;

switch( e1->var.ident ){
   case VAR:
     incdeca(e1, op );      
   break;

   case POINTER:
   /* get size of whats pointed to */
   /* assume just simple vars for now */
     if( e1->var.type != CHAR ) error("pointer add not implemented");
     incdecar(e1,op);
     break;

   default:  error("Can't inc-dec this type"); break;

   }   /* end var.ident */
 
}


void postincdec( struct EVAL *e1, int op ){
int temp,reg,siz;
struct EVAL e2;

switch( e1->var.ident ){
   case VAR:
     loadval( e1 );       /* load the value, since need preinc value */
     incdeca( e1,op );      
   break;

   case POINTER:
     loadadd(e1);
     if( e1->var.type != CHAR ) error("pointer add not implemented");
     incdecar(e1,op);
     break;

   default:  error("Can't inc-dec this type"); break;

   }   /* end switch var.ident */

   flags= 0;   /* need status of original value */

}


void negate(){
   compliment();
   stage("\taddlw\t1\n");
}

void compliment(){              /* already loaded */
   stage("\tmovwf\t_temp\n");   /* can optimize to just comf var,W */
   stage("\tcomf\t_temp,W\n");
}


void cpi( long val ){   /* compare immediate */
/* used only by switch */
/* since c26 has no compare, the value is offset from previous values */
int temp;
extern int soff;
   temp= (int)val;
   val= (int)val - soff;
   soff= temp;

   if( val > 0 ){
      if( val < 256 ) sprintf(stg,"\taddlw\t%d\n",256 - (int)val);
      else error("Case value out of range");
      }
   else{
      val= -val;
      if( val < 256 ) sprintf(stg,"\taddlw\t%d\n",(int)val);
      else error("Case value out of range");
      }

   flags= 1;
   stage(stg);

}


void  status(struct EVAL * e1){        /* generate flag status */

   if( e1->type != VALUE ) loadval(e1);
   if(flags == 0) stage("\tiorlw\t0\n");  /* not all loads gen status */
   flags= 1;
}


void store( struct EVAL *e1, int reg ){
char *p;

/* think reg is now == don't care */
/* means we can't store the FSR  */

switch ( e1->type ){

  case FOUND:
 /* assume int type */
  switch( e1->var.scope ){

     case EXTERN:
        stage("\tmovwf\tEEDATA\n");
        sprintf(stg,"\tmovlw\t%d\n",e1->var.address+e1->val); stage(stg);
        stage("\tmovwf\tEEADR\n");
        stage("\tcall\t_eewrite\n");
        break;

     case FARG:
     case AUTO:
        sprintf(stg,"\tmovwf\t%s\n",funarg), stage(stg);
        break;

     case STATIC:
     case GLOBAL:

      if( e1->val ){      /* store to member */
        p= findname(&e1->var);
        sprintf(stg,"\tmovwf\t%s+%d\n",p,e1->val);
        stage(stg);
        }
      else{                   /* ignore reg, left over */
        p= findname(&e1->var);
        ldpk( e1 );
        sprintf(stg,"\tmovwf\t%s\n",p);
        stage(stg);
        }

      break;
     }
     break;  /* end found */

     case ADDRESS:
        if( e1->var.scope == EXTERN ){
            stage("\tmovwf\tEEDATA\n");
            stage("\tcall\t_eewrite\n");
            }
        else{
           larp( e1->reg );
           sprintf(stg,"\tmovwf\tINDF\n");
           stage(stg);
           }
        break;

      case VALUE:   
      case CONSTANT: error("Can't store to that"); break;
      case TEMPVAL:
      case STACKVAL:
      case STACKADD:
        error(" Not implemented in store");
        break;

     } /* end switch type */

     e1->type= VALUE;

     /* in case there are a= b= c */
     e1->reg= reg;
     qpop();
}




void tempval( struct EVAL * e1 ){   /* store value on stack */

    if( e1->type == CONSTANT ) return;  /* don't need to store constant */

/* try to delay loading primary, when value is simple memory location */
    if( e1->var.type == CHAR &&
     ( e1->var.scope == GLOBAL || e1->var.scope == STATIC
      || e1->var.scope == FARG )) return;

    loadval( e1 );
    push( e1 );
}



void push( struct EVAL * e1){

  if( e1->type == VALUE ) e1->type= STACKVAL;
  qpush();
}

void qpush(){

  ++stackcount;
/* sprintf(stg,"\t;push  %d\n", stackcount); stage(stg); */
}

void pop(struct EVAL *e1 ){

  if( e1->type == STACKVAL ) e1->type= VALUE;
  qpop();
}

void qpop(){   /* quick pop */

/* sprintf(stg,"\t;pop  %d\n",stackcount);  stage(stg); */
  if( --stackcount < 0 )  stackcount = 0;
}



void loadval( struct EVAL * e1 ){
char *p;   
int mysize, save;

 /* flush(ALL);  printf("In loadval "); */
 /*  dump(e1);  */

  flags= 1;

  mysize= e1->datasize;
  switch( e1->type ){
     case FUNCALL:      /* only for correct jump polarity */
        e1->type= VALUE;
        flags= 0;
        qpush();
        break;

     case VALUE:             
        break;
     case STACKVAL:
        pop(e1);
        break;
     case CONSTANT:
        mysize= SOCHAR;  e1->reg= 0; 
        sprintf(stg,"\tmovlw\t%d\n",e1->val);    stage(stg);
        flags= 0;
        qpush();
        break;
     case STACKADD:  error("Internal error - Type Stackadd not used");
                     break;  
     case ADDRESS:
        if( e1->var.ident == VAR ) { /*  was just true,always */
           mysize= SOCHAR;
           switch( e1->reg ){
              case 0:  ldpk( e1 );    /* globals */
                       p= findname( &e1->var );
                       sprintf(stg,"\tmovf\t%s,W\n",p);  stage(stg);
                       break;
              case FSR: larp( e1->reg );    /*  e1->reg= 0; save where */
                        stage("\tmovf\tINDF,W\n");
                        break;
              case EEADR:
                    stage("\tmovf\tEEDATA,W\n");
                    break;

              default: error("Unknown address type in loadval");
              break;

              }
           }
        else{   /* assume pointer, get its value, not what its pointing to */
           stage("\tmovf\tFSR,W\n");
           }
        qpush();
        break;
     case FOUND:
        switch( e1->var.scope ){
           case EXTERN:
              address(e1);
              stage("\tmovf\tEEDATA,W\n");
           break;
           case GLOBAL:
           case STATIC:
              p= findname( &e1->var );
              if( e1->var.ident == ARRAY  || e1->var.ident == FUNCTION ){ 
                 sprintf(stg,"\tmovlw\t%s\n",p); stage(stg);
                 e1->reg= 0; 
                 mysize= SOCHAR;
                 flags= 0;
                 }
              else{ 
                 mysize= SOCHAR;

                 if( e1->val ){     /* member */
                  /*  address( e1 );  */
                    ldpk(e1);
                    sprintf(stg,"\tmovf\t%s+%d,W\n",p,e1->val);
                    stage(stg);
                    }
                 else{
                    ldpk( e1 );
                    sprintf(stg,"\tmovf\t%s,W\n",p );     stage(stg);
                    }
                 e1->reg= 0; 
                 }
              qpush();
              break;
           case FARG:
           case AUTO:
              
             /* preg( e1->var.offset ); */
              sprintf(stg,"\tmovf\t%s,W\n",funarg); stage(stg);
            /*  mysize= SOINT; */  e1->reg= 0;
              qpush();
              break;

           } /* end scope */
           break;

     }  /* end switch type */

  e1->type = VALUE;

#if 0 

  if( e1->datasize == 0 ) e1->datasize= mysize;
  else if( mysize != e1->datasize ){  /* gen cast code */
     save= e1->datasize;
     e1->datasize = mysize;      /* set to size actual loaded */
     cast( e1, save );           /* and change it back */
     }
#endif

}

     
/* loadadd - load pointer */
void loadadd( struct EVAL * e1 ){
char *p;
int reg;

/* flush(ALL); printf("In loadadd "); */

 if( e1->var.scope == EXTERN )error("No eeprom pointers allowed");

 switch(e1->type ) {
   case FOUND:
   switch( e1->var.scope ){
      case AUTO:
      case FARG:
      check(0);
      reg= nextarp();
      sprintf(stg,"\tmovf\t%s,W\n",funarg); stage(stg);
      stage("\tmovwf\tFSR\n");
      e1->reg= reg;
      break;

      default:   /* globals etc.. */
      check(0);  
      ldpk( e1 );
      reg= nextarp();
      p= findname( &e1->var );
      sprintf(stg,"\tmovf\t%s,W\n",p);  stage(stg);
      stage("\tmovwf\tFSR\n");
      e1->reg= reg;
      break;
      }
   break;

   case STACKADD:
   case STACKVAL:
   case ADDRESS:
   case VALUE:
   /* no code generated error("Internal - No code generated in loadadd\n"); */
   break;
   }   
 
 e1->type= ADDRESS;
}


void address( struct EVAL * e1 ){
char *p;

/*  flush(ALL);  printf("In address "); */

  if( e1->type == ADDRESS ) return;
  else{

     if( e1->type == CONSTANT ){    /* allow loading constants for short fun */
        e1->reg= nextarp();
        check(0);
        sprintf(stg,"\tmovlw\t%d\n",e1->val);  stage(stg);
        stage("\tmovf\tINDF,F\n");
        e1->type= ADDRESS;
        return;   
        }

  /* check(HL); */
     switch( e1->var.scope ){
        case FARG:
        case AUTO:
           check(0);
           sprintf(stg,"\tmovlw\t%s\n",funarg); stage(stg);
           stage("\tmovwf\tFSR\n");
           e1->reg= AR1;
           break;

        case STATIC:
        case GLOBAL:
           check(0);
           p= findname( &e1->var );
           e1->reg= nextarp();
         /*  larp( e1->reg );  */
           sprintf(stg,"\tmovlw\t%s\n",p);  stage(stg);
           if( e1->val ){
            /*  larp( e1->reg ); */       /* change div by 2 ??? */
              sprintf(stg,"\taddlw\t%d\n",e1->val ); stage(stg);
              e1->val= 0;
            /*  flush(ALL);  */
              }
           stage("\tmovwf\tFSR\n");

           break;
        case EXTERN:  /* eeprom */
           check(0);
           sprintf(stg,"\tmovlw\t%d\n",e1->val+e1->var.address);
           stage(stg);
           stage("\tcall\t_eeadr\n");
           dp= 0;   e1->reg = EEADR;
        break;
        }  /* end switch */


     e1->type= ADDRESS;
  }      /* end first else */


}


void secval( struct EVAL * e1 ){


if( e1->type == SECVAL ) return;

if( e1->type == FUNCALL ) e1->type= VALUE;  /* for jumps */

switch (e1->datasize){
   case 0:   /* unknown assume char in this case */
   case 1:
   case 2:

   /* constants and address loaded do not need data loaded */
   if( e1->type == CONSTANT ) return;
   if( e1->type == FOUND ){
      if( e1->var.scope == FARG ){
         /* e1->type= REGVAL; leave as found */
         return;
         }
      else { 
        if( e1->val || e1->var.scope == EXTERN ){
           address( e1 ); 
           }
         return;
         }
      }
   if( e1->type == ADDRESS ) return;
   
   if( e1->type == VALUE ){
      error("Simplify the expression,( or provide a secval temp)");
      }
   if( e1->type == STACKVAL ){ 
      pop( e1 );
      larp(0);
      error("No code for stackval in secval");
      }
   break;


   default: error("Type not supported");
   }
e1->type= SECVAL;
  
}


void doopstore( struct EVAL * e1, struct EVAL * e2, int op ){
char *p;
int i;

   if( e1->var.scope == EXTERN ) error("Can't store to eeprom this way");

   ldpk(e1);

   if( op == '<' || op == '>' ){  /* shift memory */
      secval( e1 );
      p= findname( &e1->var );
      if( e2->type != CONSTANT ) error("Shift value must be a constant");
      i= e2->val & 7;  /* doesn't make sense toshift more */
      sprintf(stg,"\tbcf\tSTATUS,C\n\t%s\t%s,F\n",
              op == '<' ? "rlf" : "rrf" , p );
      while( i-- ) stage(stg);
      }

   else{
      loadval( e2 );
      check(1);
      secval( e1 );
   /*   p= findname( &e1->var ); */
      switch( op ){
         case '+': stage("\taddwf\t"); break;
         case '-': stage("\tsubwf\t"); break;
         case '&': stage("\tandwf\t"); break;
         case '|': stage("\tiorwf\t"); break;
         case '^': stage("\txorwf\t"); break;
         default: error("( / %) Not supported");    /*   * / %   */
         }
      /* finish instruction */

      if( e1->var.scope == FARG ) sprintf(stg,"%s,F",funarg) , stage(stg);
         
      else if( ( e1->type == ADDRESS || e1->type == FOUND ) && e1->reg == 0 ){
         p= findname(&e1->var);
         sprintf(stg,"%s,F",p);  stage(stg);
         }
      else stage("INDF,F");    /* secval or regval  */           
      nl();

     /* sprintf(stg,"%s,F\n",p);   stage(stg); */
      }
  flags= 1;

}


void doop( struct EVAL * e1, struct EVAL * e2, int op ){
char *p;

  /*
   if( e1->datasize > e2->datasize ) cast( e2, e1->datasize );
   else if( e2->datasize > e1->datasize ) cast( e1, e2->datasize);
  */


 if( op == '>' || op == '<' || ( op == '-' && e2->type != CONSTANT) ) {
     /* shift sub special case */
    
     loadval( e1 );
     check(1);
     stage("\tmovwf\t_temp\n");
     pop(e1);
     loadval( e2 );

     if( op == '>' ) stage("\tcall\t_rshift\n");
     else if( op == '<' ) stage("\tcall\t_lshift\n");
     else{
        stage("\tsubwf\t_temp,W\n");
        }
     if( op != '-' ) stage("\tmovf\t_temp,W\n"); /* get result */

 }

 else{       /* normal operation */
 secval( e2 );    
 loadval( e1 );
 check(1);

 if( e1->datasize <= 2 ){           /* char and int code */
    if( e2->type == CONSTANT ){
      switch( op ){
         case '+':     /* sub constant uses add */
         case '-': stage("\taddlw"); break;
         case '&': stage("\tandlw"); break;
         case '|': stage("\tiorlw"); break;
         case '^': stage("\txorlw"); break;
         default: error("OP not supported");    /*   * / %   */
         }
         /* convert subtract to add 2's complement */
         sprintf(stg,"\t%d\n",(int)( op == '-' ? 256 - e2->val : e2->val) );
         stage(stg);
         
      }

   else{       /* not immediate op */

   /* set up arp and/or dp */
      if( ( e2->type == ADDRESS || e2->type == FOUND ) 
                  && e2->reg == 0 ) ldpk( e2 );
   /*   if( e2->type == ADDRESS && e2->reg != 0 ) larp( e2->reg );
      if( e2->type == REGVAL ) preg( e2->var.offset );
      if( e2->type == SECVAL ) larp( 0 );   */

      switch( op ){
         case '+': stage("\taddwf\t"); break;
         case '&': stage("\tandwf\t"); break;
         case '|': stage("\tiorwf\t"); break;
         case '^': stage("\txorwf\t"); break;
         default: error("( * / %) Not supported");    /*   * / %   */
         }
      
      if( ( e2->type == ADDRESS || e2->type == FOUND ) && e2->reg == 0 ){ 
         p= ( e2->var.scope == FARG ) ? funarg : findname(&e2->var);
         sprintf(stg,"%s,W",p);
         stage(stg);
         }
      else if( e2->var.scope == EXTERN ) stage("EEDATA,W");
      else stage("INDF,W");    /* secval or regval ?? questionable code */           
      nl();
      

      } /* end datasize delete this if?? */

    } /* end else not immediate */
 flags= 1;
 }  /* end not shift, shift only sets z for shift count so no status */

}







void compare( struct EVAL * e1, struct EVAL * e2 ){
          /* swap JLE to JGE and JG to JL for easier compare */
          /* but get incorrect code */

 doop( e1, e2, '-' );
 flags= 1;
 
}



void pad( int count ){   /* output DB to fill in array */
int i;
extern unsigned gaddress;

  if( count <= 0 ) return;
  
  if( progdata == 0 ) gaddress += count;   /* c26 paging */

  while( count ){
     stage("\tde ");
     for( i= 0; i < 10 ; i++ ){
        stage("0");
        --count;
        if( count && i < 9 ) stage(",");
        if( count == 0 ) break;
        }
     stage("\n");
     }
}

void dw( char *p ){      /* output string as data word */
extern unsigned gaddress;

   sprintf(stg,"\tdw %s\n",p);  stage(stg);
   if( progdata == 0 ) gaddress+= 1;
}



/* output literal as series of bytes terminated in a zero */
int outlit( char *p ){  
int count;
int i, c;  
int b;
char temp[5];
extern long hexval( char *p );
extern long octval( char *p );
extern unsigned gaddress;


  i= strlen( p );     /* get rid of the "" */
  if( i ){ 
     p[i-1]= 0;
     ++p;
     }
  count= 0;
  while( *p ){
     stage("\tdb ");
     for( i= 0; i < 10 ; i++ ){
        b= c= *p;
        if( c == '\\' ){
           c= *++p;
           switch( tolower(c) ){
              case 't': c= '\t'; break;
              case 'r': c= '\r'; break;
              case '\\': c= '\\'; break; 
              case '\'': c= '\''; break;
              case 'n': c= '\n'; break;
              case 'a': c= '\a'; break;
              case 'b': c= '\b'; break;
              case 'f': c= '\f'; break;
              case 'v': c= '\v'; break;

              case 'x':   /* hex value of next 1 or two digits */
                 ++p;
                 temp[0]= 'x';
                 if( isxdigit( *p ) ) temp[1]= (char) *p++;
                 else{ 
                    error("Not a hex value");
                    temp[1]= '0';
                    }
                 temp[2]= 0;
                 if( isxdigit( *p ) ) temp[2]= (char) *p;
                 else --p;
                 temp[3]= 0;
                 c= (int) hexval( temp );
              break;

              default:    /* octal value of next 1 2 or 3 digits */
                 if( isdigit( c )  && ( c < '8' || c == '0' ) ){
                    temp[0]= (char) c;
                    ++p;
                    }
                 else{ 
                    error("Not a octal value");
                    temp[0]= 0;
                    }

                 c= *p;
                 
                 if( isdigit( c )  && ( c < '8' || c == '0' ) ){
                    temp[1]= (char) c;
                    ++p;
                    }
                 else {
                    temp[1]= 0;
                    }

                 c= *p;

                 if( isdigit( c )  && ( c < '8' || c == '0' ) ){
                    temp[2]= (char) c;
                    ++p;
                    }
                 else { 
                    temp[2]= 0;
                    }
                 temp[3]= 0;
                 --p;
                 c= (int) octval( temp );
              break;
              }
         }
         sprintf(stg,"%d",c);  stage(stg);
         ++count;
         if( b == 0 ) break;
         if( i < 9 )stage(",");
         ++p;
         }
     stage("\n");
     }
  if( c != 0 ){ 
     stage("\t.db 0\n");
     ++count;
     }
  /* always in program space ??? */
  /* if( progdata == 0 ) gaddress += count; */

  return count;
}

void dbytes( long val, int size ){ /* output as list of DB's lsb to msb */
long div= 1;   
long i;
extern unsigned gaddress;
extern unsigned eaddress;

   /* c26 size=size/2; */
   if( progdata == 0  && pic == 1 ) gaddress += size;
   if( progdata == 0  && pic == 2 ) eaddress += size;

   if( pic == 1 ){
       stage("\tde ");
       fprintf(stderr,"Warning, initial values are in program space");
       }
   while( size ){
      i= (val/div) % (long)65536;
      if( pic == 1 ) {
         sprintf(stg,"%ld",i);
         stage(stg);
         }
      else{          /* code for extern with initial value */
         if( eeadr > 63 ) error("EEPROM space full");
         eedata[eeadr++]= i;
         }
      val-= i;
      div*= (long)65536;
      if( --size ) stage(",");
      }
   nl();
}



void comment( char *p ){  /* print as comment */

  sprintf(stg,"; %s\n",p);  stage(stg);
  narp= 2;               /* reset the available pointer */
  stackcount= 0;
  flush(ALL);            /* optimize across expressions ? no I think */
}


void dsect(){  /* output to data section */

   if( progdata ){    /* data goes in program space */
      csect();
      return;
      }

   if( section != DSECT ){ 
      stage("\t;data\n");
      section= DSECT;
      }
   flush(ALL);
}

void csect(){ /* output to code section */
   if( section != CSECT ){ 
      stage("\t;code\n");
      section= CSECT;
      }
   flush(ALL);
}

void nl(){           /* new output line */
   stage("\n");
}

void plabel( char *p ){    /* print a label */
extern int last_ret;

   oldoff= dp= arp= -1;                /* don't know arp or dp */
   sprintf(stg,"%s",p);  stage(stg);
   last_ret= 0;                 /* we might jump here */
}

void pilabel( int num ){   /* print a label from number */
extern int last_ret;

   oldoff= dp= arp= -1;
   sprintf(stg,"%s%d\n",hash,num);  stage(stg);
   flush(ALL);
   last_ret= 0;

}


void ds( int size ){       /* print a Data Space directive */
extern unsigned gaddress;

/* size is in bytes */
   /* mc26 size= size / 2;  */
   if( pic == 1 ){
      sprintf(stg,"\tequ %d\n",gaddress);  stage(stg);
      if( progdata == 0 ) gaddress+= size;
      }
   else error("Uninitialized EEPROM location");

}

void jump( int lab){             /* jump */

   if( flags == 0 && jumpval != ALWAYS ){
      stage("\tiorlw\t0\n");
      }

   switch( jumpval ){
      case JE:   stage("\tbtfsc\tSTATUS,Z\n");
                 stage("\tgoto");   break;
      case JNE:  stage("\tbtfss\tSTATUS,Z\n");
                 stage("\tgoto");   break;
      case JL:   stage("\tbtfss\tSTATUS,C\n");
                 stage("\tgoto");   break;
      case JGE:  stage("\tbtfsc\tSTATUS,C\n");
                 stage("\tgoto");  break;
      case ALWAYS:  stage("\tgoto");  break;

      case JLE:                             /* Z or C=0 */
          stage("\tbtfss\tSTATUS,Z\t;_JLE\n");        /* z=1 skips C check */
          stage("\tbtfss\tSTATUS,C\n");
          stage("\tgoto");  /* c=1 skips goto  */
          break;

      case JG:                              /* z=0 and c=1 */
          stage("\tbtfss\tSTATUS,Z\t;_JG\n");     /* z=1 skips C check and goto */
          stage("\tbtfss\tSTATUS,C\n");     /* c=1 skips skip and does goto */
          stage("\tgoto\t$+2\n");   /* just a skip, always true */
          stage("\tgoto");    
          break;
      default:  error(" Unknown jump condition");
      }

   sprintf(stg,"\t%s%d\n",hash,lab);  stage(stg);
   flags= 0;
   stackcount= 0;  /* or should be, can't carry push past a branch */
}


void outline( char *p ){  /* just print out the line */

  sprintf(stg,"%s",p);  stage(stg);
  flush(ALL);

}

void pjump( char *p ){  /* print jump to label, used by goto */

  sprintf(stg,"\tgoto\t%s,*\n", p);  stage(stg);
}


void pextern( char *p ) {
  /* assembler has limit of 10 includes */
  /* resort to a source linker for library */
  
/*sprintf(stg,"\t.include \\dsp\\mc26\\mc26lib\\%s.asm\n", p);  stage(stg);*/
  sprintf(stg,"\textrn\t%s\n",p);  stage(stg);

}

void end(){

   stage("\tend\n");
   flush(ALL);
}


void dumpdata(){
int i;

   if( eeadr == 0 ) return;
   stage("\torg\t0x2100\t;eeprom constant data\n");
   for( i= 0; i < eeadr; ++i ){
      sprintf(stg,"\tde\t%d\n",eedata[i]);
      stage(stg);
      }

}

void larp( int num ){       /* load the arp with num */
   if( arp == num ){ 
      return;
      }
   arp= num;
   /* sprintf(stg,"\tlarp\tar%d\n",num);  stage(stg); */
}



/* function name from c26 dsp, inplementing only rp0 for the 16f84,
   indirect bank( irp bit)  not supported, not needed */
void ldpk( struct EVAL *e ){   

int page;
int reg;

   if( e->var.address == -1) return;   /* extern- eeprom no paging */
   page= e->var.address / 128;
   reg= e->var.address & 127;
 /* page one shadows page zero, so just be concerned with
    hardware registers that are different  */
   if( page != dp && (reg == 1 || ( reg >= 5 && reg <= 9) ) ){
        sprintf(stg,"\t%s\tSTATUS,RP0\n",(page == 1) ? "bsf":"bcf" );
        stage(stg);
        dp= page;
        }
}     


void rel(int size){            /* release stack space at end of block */
}




void stackspace(){               /* allocate space to auto's */
}
                   

void stackvar( int size ){        /* count space needed for auto's */
   totalsize+= size;
   flush(ALL);
   error("No local variables, use global or static");

}

void center(char *p){                    /* enter a c function */
extern unsigned stackoff;
extern unsigned gaddress;

   flush(ALL);
   if( stackoff ){       /*  do we have an argument */
      if( stackoff > 1 ) error("Only one function argument allowed");
      dsect();
      /* make up a variable name */
      strcpy(funarg,"_");
      strcat(funarg,p);
      sprintf(stg,"%s\tequ\t%d\n",funarg,gaddress++);
      stage(stg);
      }
   csect();
   plabel( p );
   nl();  
   if(*p == '_') shortfun= 1;

   if( stackoff ){   /* store w reg */
      sprintf(stg,"\tmovwf\t%s\n",funarg);
      stage(stg);
      }

/*   arp= 0; oldoff= 0;  */
   flush(ALL);
}


int nextarp(){  /* kept for error check, next indirect is always FSR */


   if( narp >= 3 ){
      flush(ALL);
      error("FSR is in use - simplify the expression");
      }
   return FSR;
}


void pushadd(){

   ++narp;       /* just use the next available register */
}

void popadd(){
   
   --narp;
}
   
void pointeradd( struct EVAL *e1, struct EVAL *e2, int op ){
struct SYMBOL one;
struct EVAL e3;
int s, reg;
char *p;


/*  flush(ALL);  printf("In pointeradd ");  */

 /* just regular if both are pointers */
 if( (e2->var.ident == POINTER || e2->var.ident == ARRAY) &&
    ( e2->type != CONSTANT ) ){
    doop( e1, e2, op );
    return;
    }

 /* adjust size of e2 according to e1 parameters */
 copysymbol( &one, &e1->var );
 if( one.ident == ARRAY ){
    if( one.size2 ){       /* double arrary */
       one.size2= 0;
       s= size( &one );
       }
    else s= sizeone( &one );
    }
 else{        /* its a pointer */
    one.ident= VAR;
    s= size( &one );
    }
 /* size is half because C26 addresses on word boundary */
 /* s= s/2; */

 if( e2->type == CONSTANT ) e2->val *= (long)s;
 else if( s == 1 ) ;   /* don't need to adjust */
 else{
    loadval( e2 );
    e3.type= CONSTANT;
    e3.val= (long) s;
    e3.datasize= 2;
    doop( e2, & e3, '*' );   /* multiply by size */
    }

 /* now do the original operation */

 /* optimize constants - no code generated yet */

 if( e1->type == FOUND && e2->type == CONSTANT  &&
       ( e1->var.scope == STATIC || e1->var.scope == GLOBAL ||
       e1->var.scope == EXTERN ) ){

    if( e1->var.scope != EXTERN ){
       check(0);   nextarp();
       p = findname(&e1->var);
       if( e1->var.ident == POINTER ){
          sprintf(stg,"\tmovf\t%s,W\n",p);  stage(stg);
          sprintf(stg,"\taddlw\t%d\n",e2->val);  stage(stg);
          }  
       else {    /* else array */
          sprintf(stg,"\tmovlw\t%s+%d\n",p,e2->val);  stage(stg);
          }
       stage("\tmovwf\tFSR\n");
       if( op == '-' ) error("Negative array offset");
       e1->type = ADDRESS;
       e1->reg = FSR;
       return;
       }
    else{    /* it is EXTERN == eeprom */
       if( e1->var.ident == POINTER ) error("Can't have pointers in eeprom");
       check(0);
       sprintf(stg,"\tmovlw\t%d\n",e2->val+e1->var.address+e1->val);
       e1->val= 0;
       stage(stg);   stage("\tcall\t_eeadr\n");
       if( op == '-' ) error("Negative array offset");
       e1->type = ADDRESS;
       e1->reg = EEADR;
       return;
      } 

   }

 /* code for stack pointer and constant */
 /* always a pointer, array not on stack */
 if( e1->type == FOUND && e2->type == CONSTANT && ( e1->var.scope == FARG ||
     e1->var.scope == AUTO ) ){
     check(0);
     sprintf(stg,"\tmovf\t%s,W\n",funarg); stage(stg);
     sprintf(stg,"\taddlw\t%d\n",e2->val); stage(stg);
     stage("\tmovwf\tFSR\n");
     e1->type = ADDRESS;
     e1->reg= FSR;
     if( op == '-' ) error("Negative array offset");
     return;
     }


 if( e1->type == TEMPVAL ||  e1->type == VALUE || e1->type == STACKVAL ||
    e1->type == ADDRESS ){  /* may as well say not found */
 /* the value was already loaded into accum, so finish with doop */
    doop( e1, e2, op );
    /* now get result into a register */
    reg= nextarp();
    larp( 0 );
    sprintf(stg,"\tmovwf\tFSR\n");  stage(stg);
    qpop();
    e1->type=ADDRESS;
    e1->reg= FSR;
    flags= 0;
    if( e1->var.scope == EXTERN ) error("no code generated for eeprom var");
    return;
    }


    /* new try at this for C26 */
    /* set size */
    if( e2->datasize == 0 ) e2->datasize= SOCHAR;
    if( e1->datasize == 0 ) e1->datasize= SOCHAR;
  /* don't want to do op backwards as want result in e1 stucture */
  /* doing the add backwards may be better for the code generated */

    loadval( e2 );  /* this is probably already loaded anyway */
    check(1);
    switch ( e1->var.scope ){

       case EXTERN:
          if( e1->var.ident == POINTER ) error("Can't have eeprom pointers");
          sprintf(stg,"\t%s\t%d\n",
               (op == '+' ) ? "addlw" : "sublw",
               e1->var.address+e1->val );
          e1->val= 0;
          stage(stg);  stage("\tcall\t_eeadr\n");
       break;

       case STATIC:
       case GLOBAL:
       p= findname( &e1->var );
       if( e1->var.ident == ARRAY ){       /*  e1->var.ident == ARRAY */
          switch (op){    
             case '+':  
             sprintf(stg,"\taddlw\t%s\n",p);  stage(stg);
             break;
             case '-':
             sprintf(stg,"\tsublw\t%s\n",p);  stage(stg);
             break;
             }
          }
       else {   /* ident should be pointer */
          switch (op){    
             case '+':  
             sprintf(stg,"\taddwf\t%s,W\n",p);  stage(stg);
             break;
             case '-':
             sprintf(stg,"\tsubwf\t%s,W\n",p);  stage(stg);
             break;
             }
          
          }
       break;  /* end static */

       case FARG:
       case AUTO:    /* array and pointers are same */
                     /* can't have real array on stack */
          p= funarg;
          switch (op){    
             case '+':  
             sprintf(stg,"\taddwf\t%s,W\n",p);  stage(stg);
             break;

             case '-':
             sprintf(stg,"\tsubwf\t%s,W\n",p);  stage(stg);
             break;
             }

       break;

       } /* end switch scope */

    
    
    
    /* now get result into a register */
    /* skip if not fully dereferenced */
    if( e1->var.ident == ARRAY && e1->var.size2 ){ 
       e1->type= VALUE;
       return;
       }

    if( e1->var.scope != EXTERN ){
       reg= nextarp();
       stage("\tmovwf\tFSR\n");
       e1->reg= FSR;
       }
    else e1->reg= EEADR;
    qpop();
    e1->type=ADDRESS;
    flags= 0;



}
