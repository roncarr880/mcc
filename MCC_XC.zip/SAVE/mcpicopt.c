/* optimize larp and adrk and sbrk instructoins */

#include <stdio.h>
#include <string.h>
#include "mcout.h"

extern void error( char *p );

static char buf[ALL+1][100];   /* stage buffer */
static int id;                  /* current index */

char history[100];             /* last line staged */

char * p2tab( char *p ){  /* find 2nd tab in string */

   while( *p ) if( *p++ == '\t' ) break;
   while( *p && *p != '\t' ) ++p;
   return ++p;                     /* return just past tab */
}
      

void flush( int n ){     /* print out all up to n */
int i, k;

  for( i= 0; i <= n ; i++){ 
     if( i == id ) break;        /* reached current index */
     if( i == id - 1 && strstr(buf[i],"adrk")) break;  /* save adrk */
     printf("%s", &buf[i] );
     }


  /* see if any left */
  for( k= 0; ; k++, i++ ) {
     if( i == id ) break;
     strcpy( buf[k],buf[i] );    /* copy down the ones left */
     }

  id= k;                         /* k has new current index */
  buf[id][0]= 0;                 /* kill line */
}



void subst(char *p1, char *p2 ){  /* sub in text */

   while( *p2 ) *p1++ = *p2++;

}



void stage( char *p ){     /* put lines into the buffer */
char *e, *p2, *p3;
int len;
int iw;
char temp[100];
int val1, val2;


  strncat( buf[id], p, 100 ); 
  len= strlen( buf[id] );
  if( len > 100 ) error("Line is too long for stage buffer");

  if( buf[id][len-1] != '\n' ) return;  /* still more needed in this line */

  strcpy( history, buf[id] );           /* remember this line */

  iw= id++;     /* establish a working index, global is counted up */
  if( id == ALL ){ 
     flush(ALL); /* don't overfill the buffer */
     return;
     }
  buf[id][0]= 0;                 /* kill next line */

  /* do optimizations */
  

  if( iw > 1 &&
      buf[iw][0] == ';' &&
      strstr(buf[iw-1],"movwf") &&
      strstr(buf[iw-2],"movlw\t0") ){    /* load zero */
     buf[iw-2][0] = ';';
     subst(buf[iw-1],"\tclrf ");
     }

  if( buf[iw][0] == ';' ) return;  /* just a comment */
  
  if( strchr( buf[iw], '*' ) != 0 ){  /* old mc26 code */
     /* this one uses indirect mode - flush all previous */
     flush( iw - 1 );  /* kept for flush example */
     return;
     }

                  /* compare to zero */
   if( iw > 1 &&
      strstr(buf[iw-2],"\taddlw\t256") &&
      strstr(buf[iw-1],"\tbtfss\tSTATUS,Z") &&
      strstr(buf[iw],"\tgoto")  ){  /* test == 0 */
      buf[iw-2][0]= ';';
      flush(ALL);
      }


   /* try a pic optimize */
   if( iw > 1 &&
      strstr(buf[iw],"return") &&
      strstr(buf[iw-1],"iorlw\t0") &&
      strstr(buf[iw-2],"movlw")  ){         /* return a constant */

      p2= p2tab(buf[iw-2]);
      if( *p2 >= '0' && *p2 <= '9' ){         /* check not a pointer */
          /* change movlw to retlw */
         buf[iw-2][1] = 'r';
         buf[iw-2][2] = 'e';
         buf[iw-2][3] = 't';
         buf[iw-1][0]= buf[iw][0] = ';';  /* comment extra lines */
         flush(ALL);
         return;
         }
      }


   /* do while opt */
   if( iw >= 5  &&
      buf[iw][0] != '\t'   &&  /* its a label, already returned on comment*/
      strstr(buf[iw-1],"goto")  &&
      strstr(buf[iw-2],"goto")  &&
      strstr(buf[iw-2],buf[iw]) &&   /* match label with goto */
      strstr(buf[iw-3],"\tbtfsc\tSTATUS,Z") &&
      strstr(buf[iw-4],"movf") &&
      ( strstr(buf[iw-5],"incf") || strstr(buf[iw-5],"decf") )
      ) {
      /* capture var name and match it */
      p2 = p2tab(buf[iw-5]);
      p3 = p2tab(buf[iw-4]);
      strcpy(temp,p3);
      len= strlen(temp);  temp[len-2] = 'F';
/* printf("%s",temp); */
      if( strcmp( temp,p2 ) != 0 ) return;

      /* temp has var,F */
      if( strstr(buf[iw-5],"incf" )) strcpy(buf[iw-5],"\tincfsz\t");
      else strcpy(buf[iw-5],"\tdecfsz\t");
      strcat(buf[iw-5],temp);
      buf[iw-4][0] = buf[iw-3][0] = buf[iw-2][0] = ';';

      /* printed label, next command is flush */

   }/* end opt do while  */


}


     
