#include <pic16f84.h>


/* -------------------- user code follows -------------------- */

char var1,var2,var3,var4;
char *p;
char a[5];
struct {
  char s;
  char t;
  char p;
  } st;

union {
  int i;
  struct{
     char low;
     char hi;
     } bt;
  } U;


_interupt(){

}


main(){

   var1= 0x4f;
   if( test1() != var1 ) err(1);
   /* keep all vars same from test 1 */
   if( test2() !=  1   ) err(2);

   /* function gens status */
   var1= 0 , ++var1;   /* !z status, comma operator */
   if( test3() )  err(3);   

   test4(var1);     /* test arrays, var1 from previous test */
   if( a[1] != 10 ) err(4);

   if( test5() ) err(5);

   switch(test6()){

       case 8: err(6); break;
       case 53: err(6); break;
       case 1: break;  /* good return, others error */
       case 4:  /* nobreak */
       default: err(6);
   }
  /* test 7 */
   var1= 15;
   var2= 43;
   var3= ~var1;   /* 240 */
   var4= -var2;   /* 213 */
   if( var3 != 240 || var4 != 213 ) err(7);

   p= a;
   test8(p);
   if( var1 - var2 == 1 && a[2] == 0 );  /* ok */
   else err(8);

}

err(char num){
static char err;

 err= num;
 while(1);

}

char test1(){
static char var1;   /* scoping test, same name as global */

     var1= 0;
     TRISB = 0x55;  /* paging test */
     EEADR = 0x7;
     TRISA = 0xff;

     /* simple expressions + paging */

     var2 = var1 + EEADR;   /* 7 */
     var3 = TRISB | var2;   /* 57h */
     var3 ^= 1;             /* 56h */
     var4 = var3 - var2;    /* 4f */     /* subtraction order */
     return var4;

}

char test2(){   /* var1= 4f, others from test1 */
     /* test inc/dec of variables and some simple pointers */

     p= &var2;
     *p = ++var1;    /* var1,2 = 50h */
     *++p = 1;       /* var3 = 1 */
     var4= var3-- + var1;   /* var3=0 var4=51 */
     var1-= var2;           /* var1= 0 */
     var4-= ( var2 + var3 + var1 );   /* 1 i think */
     return var4;


}

char test3(){   /* function does not always gen status */
                /* caller must gen status */
   return 0;
}

void test4(char val){
                       /* arrays */
   a[val] = val;       /* set each to its index */
   p= &a[4];
   *p= 4;
   var1= a[4];
   a[3]= var1 - val;
   --p--;              /* point to 2 */
   *p= 2;
   a[0]= val - 1;

   /* slip in a for loop */
   for( var1= var2= 0; var2 < 5; ++var2 ){
      var1 +=  a[var2];
      }
   a[1]= var1;        /* 0+1+2+3+4 */ 

}

char test5(){   /* test conditional exp, compound if */

   var1= 5;
   var2= ( var1 > 10 ) ? var1: var1 - 2;  /* 3 */
   var3= var4= 0;
   if( var1 <= 10 && var2 != var1 ) var3= 10;  /* true */
   /* should get early out and var1= 0 not done */
   if( var3 >= 10 || var1 = 0 ) var4 = 2;
   return ( var3 - var1 - var2 - var4 );  /* 0 */
}

char test6(){    /* shift some data */

   var1= 1;
   var2= 4;

   var1= var1 << var2;   /* shift up 4, down 2, down2, by zero */

   var1= var1 >> 2;
   var1 >>= 2;

   var2= 0;
   var1= var1 >> var2;

   return var1;
}

void  test8( char *cp ){
   *cp = 5;
   cp[1] = 6;
   var1= cp[0];     /* 5 */
   var2= *cp;        /* 5 */
   ++cp;
   cp++;
   *cp-- = var1 - var2;  /* a[2] = 0 */
   var1 = *cp--;         /* 6 */
   var2 = *cp;           /* 5 */

}
