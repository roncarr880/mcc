/* 
  The dska assembler seems to have a limit of 10 include files.  This looks
  like a bug.  An updated version may exist, but the source linker will
  work even if the updated version still has the bug.

  Source linker finds  \textrn\t in the output file and copies in the
  named file.

*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>



FILE *fp, *fpi;


main( int argc, char *argv[] ){
char temp[255];
char temp2[80];
char *p;
int err;

   err= 0;
   if( argc < 2 ) {
      printf("Need the name of the input file");
      exit(1);
      }

   if( ( fp= fopen(argv[1],"r") ) == 0 ){
      printf("Can't open %s",argv[1]);
      exit(1);
      }

   while(  fgets( temp,255,fp ) ){   /* get a line */
      if( strstr( temp,"\textrn\t" ) ){    /* get the file */
         p= strchr(temp,'\n');          
         if( p ) *p= 0;              /* kill return on end of line */
         strcpy( temp2,"\\dsp\\mc26lib\\");
         strcat(temp2,&temp[7]);   /* get the file name */
         strcat(temp2,".asm");

         if( (fpi= fopen(temp2,"r") ) == 0 ){
            printf("Can't open include file  %s\n",temp2);
            err= 1;
            }
         else{                  /* copy in the file */
            while( fgets( temp,255,fpi ) )  printf("%s",temp);
            fclose( fpi );
            }
            
         }
      else printf("%s",temp);
      }


   fclose( fp );
   exit( err );
   
}
