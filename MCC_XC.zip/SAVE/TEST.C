/* try out mcc compiler */

int a1;

int *a2;

int **a3;

int a4[5];

int * a5[4];

int a6[3][2];

int  f7();

int  f7p5( char b );

int * f8();

int a10[];

int  (* f10)();

int ( * screen )[25][80];


struct TAG{
 int a;
 int b;
 } ;

struct TAG2{
 int a;
 int b;
 } s2 ;

struct TAG  s1;

struct TAG3{
 int a;
 struct TAG3 *p;
 } s3;

