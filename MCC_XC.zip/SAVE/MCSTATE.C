/* statement level parsing */

/*
   break, else, switch, case, return, continue, for,
   default, goto, do, if, while
*/

#include <string.h>

#include "mcc.h"
#include "mcexp.h"
#include "mcout.h"
#include "mcsym.h"

extern char *lp;
extern char word[];
extern char hash[];
extern int label;
extern int jumpval;

void statement();

/* global switch, break and continue labels */
int gbreaklab, gcontlab;
int casein, caseout;
int gdeflab;
int last_ret;
int soff;          /* global switch offset */

void doreturn(){

  next();
  if( match(";") == 0 ) cexpression();  /* cexp gens status flags */
     
  preturn();       /* print return */
}



void dogoto(){

  next();
  pjump( word );

}

void dodo(){
int startlabel;
int savebreak;
int savecontinue;
extern int stackout, stackin;

   savebreak= gbreaklab;
   savecontinue= gcontlab;
   startlabel= label++;
   gcontlab= label++;
   stackin= stackout= -1;

   pilabel( startlabel );
   next();
   statement();            /* loop body */
   pilabel( gcontlab );    /* continue label */
   next();
   if( match("while") == 0 ) error("Expected while");
   next();
   jumpval= JNE;
   cexpression();
   if( stackout != -1 ) gbreaklab= stackout;
   else gbreaklab= label++;
   jumpval= -jumpval;
   jump( gbreaklab );
   if( stackin != -1 ) pilabel( stackin );
   jumpval= ALWAYS;
   jump( startlabel );
   pilabel( gbreaklab );

   gbreaklab= savebreak;
   gcontlab= savecontinue;

}


void dofor(){
int startlabel;
int savebreak;
int savecontinue;
char temp[128];
int c;

extern int stackout, stackin;

  savebreak= gbreaklab;
  savecontinue= gcontlab;
  startlabel= label++;
  gcontlab= label++;

  next();
  if( match("(") == 0 ) error("Expected paren");
  next();
  expression();      /* init expression */
  pilabel( startlabel );
  stackin= stackout= -1;
  jumpval= JNE;
  next();
  if( match(";") == 0){    /* don't gen code if null expression */
     cexpression();         /* test expression */
     if( stackout != -1 ) gbreaklab= stackout;
     else gbreaklab= label++;
     jumpval= -jumpval;    /* jump out */
     jump( gbreaklab );
     }
  else gbreaklab= label++;

  next();                  /* save the update expression for the end */
  temp[0]= 0;
  c= 1;
  while( lp ){
/* didn't work     strcpy( temp," ( " );  /* 1/97 try this for missing bracket problem */
     strcat( temp, word );
     strcat( temp, " " );
     if( match("(") ) ++c;
     if( match(")") ) --c;
     next();
     if( c == 0 ) break;
     }

  if( stackin != -1 ) pilabel( stackin );

  statement();            /* for loop body */
  pilabel( gcontlab );
  strcpy( word, temp );   /* put back the update expression */
  unnext();
  next();
  expression();
  jumpval= ALWAYS;
  jump( startlabel );
  pilabel( gbreaklab );

  gbreaklab= savebreak;
  gcontlab= savecontinue;

}


void dodefault(){

   if( gdeflab ) error("More than one default");
   if( casein )  pilabel( casein );     /* fell into the default code */
   next();
   if( match(":") == 0 ) error("Expected colon");
   gdeflab= label++;
   pilabel( gdeflab );
   casein= label++;             /* we might fall to next case */


}


void docase(){
long val;


   if( casein ){               /* fall to next case,  no break */
      jumpval= ALWAYS;
      jump( casein );
      }
   else casein= label++;      /* first case in switch, or break found */

   if( caseout ) pilabel( caseout );
   caseout= label++;
   for(;;){
      next();
      val= const_exp();
      next();
      if( match(":") == 0) error("Expected colon");
      cpi(val);
      next();
      if( match("case") ){
         jumpval= JE;
         jump( casein );
         continue;                 /* do next case */
         }
      else{
         unnext();
         jumpval= JNE;
         jump( caseout );
         break;                    /* case does not follow */
         }
      }

   pilabel( casein );
   casein= label++;                /* next forward label */
}

void doswitch(){
int savebreak;
int savein, saveout;
int savedefault;
int saveoff;

   savein= casein;
   saveout= caseout;
   savebreak= gbreaklab;
   savedefault= gdeflab;
   saveoff= soff;

   soff= gdeflab= casein= caseout= 0;
   gbreaklab= label++;
   next();
   if( match("(") == 0 ) error("Missing paren");
   next();
   cexpression();
   next();
   statement();


   if( gdeflab ){          /* there is default code for all caseouts */
      jumpval= ALWAYS;
      if( casein ) jump( gbreaklab );   /* no break on last case */
      pilabel( caseout );
      jump( gdeflab );
      }
   else pilabel( caseout );

   pilabel( gbreaklab );

   gbreaklab= savebreak;
   casein= savein;
   caseout= saveout;
   gdeflab= savedefault;
   soff= saveoff;
}



void dobreak(){

   if( gbreaklab == 0 ) error("No active loop");
   jumpval= ALWAYS;
   jump( gbreaklab );
   next();
   casein= 0;     /* case does not fall through to next one */
}

void docontinue(){

   if( gcontlab == 0 ) error("No active loop");
   jumpval= ALWAYS;
   jump( gcontlab );
   next();
}



void dowhile(){  /* while( expression ) statement */
int breaklabel;
int contlabel;
int savebreak, savecont;

extern int stackout, stackin;

   stackin= stackout= -1;
   savebreak= gbreaklab;      /* save any active labels */
   savecont= gcontlab;

   contlabel= label++;
   pilabel( contlabel );
   next();
   if( match("(") == 0 ) error("Missing paren");
   jumpval= JNE;
   next();          /* eat () */
   cexpression();
   next();
   jumpval= -jumpval;          /* last jump is out */
   if( stackout != -1 ) breaklabel= stackout;
   else  breaklabel= label++;
   jump( breaklabel );

                            /* set up labels for this loop */
   gbreaklab= breaklabel;
   gcontlab= contlabel;

   if( stackin != -1 ) pilabel( stackin );

   statement();             /* do the loop statement */
   jumpval= ALWAYS;
   jump( contlabel );       /* loop always */

   pilabel( breaklabel );   /* end */

   gbreaklab= savebreak;    /* restore any active labels */
   gcontlab= savecont;

}


void doif(){  /* if statement  if( expression ) statement else statement; */
int outlabel;
int elabel;

/* try this */
extern int stackout;
extern int stackin;
stackout= stackin= -1;

   elabel= 0;
   next();
   if( match("(") == 0 ) error("Missing paren");
   jumpval= JNE;
   next();          /* eat () */
   cexpression();
   if( match(")") == 0 ) error("Missing paren");
   next();
   jumpval= -jumpval;          /* last jump is out */
   if( stackout != -1 ) outlabel= stackout;
   else  outlabel= label++;
   jump( outlabel );
   if( stackin != -1 ) pilabel(stackin);
   statement();

   /* look for else */
   next();
   if( match("else") ){
      jumpval= ALWAYS;
      elabel= label++;
      jump( elabel );
      }
   else unnext();        /* its not else, put it back */

   pilabel(outlabel);    /* done with if */

   /* finish else */
   if( elabel ){
      next();
      statement();
      pilabel( elabel );
      }

}


void statement(){


   if( match(";") ) return;    /* null statement or end of statement */

   if( match("{") ){           /* start of block */
      block();
      next();                  /* eat } */
      return;
      }

   if( *lp == '}' ) return;    /* end of block */


   if( match("return") ){
     last_ret= 0;
     doreturn();
     last_ret= 1;        /* flag to avoid two returns in row */
     return;
     }
   last_ret= 0;          /* reset that flag */

   if( match("switch") ){
      doswitch();
      return;
      }

   if( match("case") ){
      docase();
      return;
      }


   if( match("if") ){
      doif();
      return;
      }

   if( match("while") ){
      dowhile();
      return;
      }

   if( match("continue") ){
      docontinue();
      return;
      }

   if( match("break") ){
      dobreak();
      return;
      }

   if( match("for") ){
      dofor();
      return;
      }

   if( match("do") ){
      dodo();
      return;
      }

   if( match("default") ){
     dodefault();
     return;
     }

   if( match("goto") ){
     dogoto();
     return;
     }

   if( match(")")) error("Extra paren");


   if( *lp == ':' ){   /* its a label */
      plabel( word );
      nl();
      next();
      return;
      }

/* if nothing else then it should be an expression */
   jumpval= JNE;    /* for  a= ( b & 1 ) ? 1 : 2 type expression */

   expression();

}


