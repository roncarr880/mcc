#include "mcsub.h"
#include "mcexp.h"
#include "mcc.h"


#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

extern char word[];
extern char *lp;

void putback();
long qtoint();

long hexval( char *p ){    /* p points to x in hex string */
long val;

   ++p;                   /* get past the x */
   sscanf(p,"%lx",&val);
   return val;
}

long octval( char *p ){   
long val;

   sscanf(p,"%lo",&val);
   return val;
}

/* evaluate if word is a constant of some sort */

int constval( struct EVAL * e ){
double val;
long ival;
char temp[20], *p;

   if( isdigit( word[0] ) || word[0] == '.' ){

/* got to put float type back together - so check for that */
      putback();
      if( strfind( word,"qQ") ){  /* its in q format for c26 */
         e->val= qtoint() ;
         }

      else if( p=strfind( word,"xX") )e->val= hexval(p);

      else if( strfind( word,".eE" ) ){  /* float */
         sscanf(word,"%lf",&val);
      /* *** need to gen some code for float */
         }


      else{ 
         sscanf(word,"%li",&ival);   /* its decimal */
         e->val=  ival ;
         }
 /* need to gen code for long value - int value is ok */
      e->type= CONSTANT;
      next();
      return 1;
      }

   if( word[0] == '\'' ){
      word[ strlen(word) -1 ]= 0;
      strcpy( temp,&word[1] );   /* get a copy without the '' */
      if( temp[0] == '\\' ){
         switch( tolower(temp[1]) ){
            case 'a':  ival= '\a'; break;
            case 'b':  ival= '\b'; break;
            case 'f':  ival= '\f'; break;
            case 'n':  ival= '\n'; break;
            case 'r':  ival= '\r'; break;
            case 't':  ival= '\t'; break;
            case 'v':  ival= '\v'; break;
            case '\\': ival= '\\'; break;
            case '\'': ival= '\''; break;
            default:
               if( (p= strfind(temp,"xX")) ) ival= hexval( p ); 
               else ival= octval( &temp[1] );
               break;
            }
         }

      else{
         /* convert ascii letter to a number */
          ival= temp[0];
          }



      e->val=  ival;
      e->type= CONSTANT;   /* these are all integer constants */
      next();
      return 1;
      }

   return 0;
}


void putback(){   /* put float types back together */
char tempword[50];


   if( *lp == '.' ){
      strcpy(tempword,word);
      next();
      strcat(tempword,word);
      next();
      strcat(tempword,word);
      strcpy(word,tempword);
      }

   else if( word[0] == '.' ){
      strcpy(tempword,"0.");
      next();
      strcat(tempword,word);
      strcpy(word,tempword);
      }

}


long qtoint(){
char temp[50];
char *p;
int i;
double val;
   
/* get the value */

   i= 0;
   p= word;
   while( *p != 'q' && *p !='Q' ){
      temp[i++]= *p++;
      }
   temp[i]= 0;

   sscanf(temp,"%lf",&val);

/* get the radix */

   i= 0;                /* skip the q */
   do{
        temp[i++]= *++p;
     }  while( *p );    /* copies terminator also */

  sscanf(temp,"%d", &i);

/* convert the value */
   while( i-- ) val *= 2;

   return (long) val;      /* return a long int */

}
