
/* test array addressing */

char val;
char val2;

char solution[8];
char *p;
int   i;
int j,k;

char msg[] = "Hello";

main( char a1 ){
char f1,f2;
char *p2;

   val = f1;
   val2 = solution[3];

   f1 = solution[val];
   solution[2] = f2;
   solution[val2] = a1;
   p = solution;

   puts( &solution[f1] );

   f1 = *p;

   i = j + 1;
   j = i - 3;
   i = j + k;
   k = i - j;

   puts( msg );
   delay( 3000 );
   delay( i );
   delay( f1 );   /* char */

   puts( p );
   puts( p2 );

}

