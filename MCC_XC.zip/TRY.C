
#include "pic16f84.h"


#pragma pic 20




char val1;

try( char val2 ){

static char val3;

   val1 <<= 1;
   val3 <<= 3;
   val2 <<= 2;

}

