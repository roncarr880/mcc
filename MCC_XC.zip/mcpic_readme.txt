The barebones documentation for mcpic compiler.

It is a barebones, close to the hardware compiler.

Basics:
  char data only
  arrays, structures supported
  EEdata using the extern keyword - extern char eedat = 38;
  pointers work, but the array code is much better
  simple #defines, no macros
  One function argument - type char of course. Actually stored as a static.
  Drop to assembly at any time using #asm #endasm ( on different lines )
  if, while, do with compound conditionals ( the big advantage of a
    higher level language is having the branch go where it is supposed to.)
  switch, case

  direct data banking with somewhat optimized bitset,bitclears

  no special pseudo function calls to remember, just real C code used.
  no ANSII - this is C the way it should be.

  no typedef, enum
  indirect banking left to the programmer
  program paging left to the programmer

  Flexible support for different devices using #pragma directives

  Capable of serious work.

***************************************************************
Setting up

Put the microchip inc file in a #asm #endasm block
  Suggest putting it in a .h file for each project
You probably will want to change the config for your hardware

Add a small section of assembly for the vectors and runtime
  This section will need to be changed slightly for different devices
  depending upon the vectors and banks for the eeprom read registers
  I  always loop the main function from this code
  I like also to call an init from the reset.

       ;declare constants used by the compiler
       list p = 16F84a
       radix  decimal

       ; change config if needed
       __config  _RC_OSC & _WDT_OFF & _PWRTE_ON


       ;set up vectors
       org   0          ; reset vector
       call  main       ; loop
       goto  0
       org   4
       goto  _interupt  ; comment this out if you don't want interupts
                        ; otherwise supply a _interupt() C function

 ; -------------------- run time library  -------------------- */

        ; shifting, shift _temp with count in W
_rshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; unsigned shift, mask bits
        rrf     _temp,F
        addlw   255        ; sub one
        goto    _rshift

_lshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; arithmetic shift
        rlf     _temp,F
        addlw   255        ; sub one
        goto    _lshift

_eeadr                     ; set up EEDATA to contain desired data
        bcf     STATUS,RP0
        movwf   EEADR      ; correct address in W
        bsf     STATUS,RP0
        bsf     EECON1,RD
        bcf     STATUS,RP0
        movf    EEDATA,W
        movwf   _eedata
        return

End the asm block with #endasm

Declare all the registers you are going to use again as C variables
Use #pragma pic directive to specify addresses in decimal
  Notice the radix above is decimal - the compiler uses decimal

Example for 16F84

                     /* set up page two registers */
#pragma pic 128   
char IND2;
char OPTION_REG;
char PCL2;
char STATUS2;
char FSR2;
char TRISA;
char TRISB;
char _unused2;
char EECON1;
char EECON2;
char PCLATH2;
char INCON2;

                   /* declare page one registers */
#pragma pic 0

char INDF;
char TMR0;
char PCL;
char STATUS;
char FSR;
char PORTA;
char PORTB;
char _unused;
char EEDATA;
char EEADR;
char PCLATH;
char INTCON;

char _temp;     /* temp location for subtracts and shifts */
char _eedata;   /* eedata in access ram */

End of .h file

Supply the two above File Register locations in an access bank.
Note that all the ram in a 16F84 is an access bank as it is shadowed
in page 2.

Why there is a runtime:
  Shifts need to be masked to make them logical shifts
  EE data can be used just like any other variable.
    ( declare with extern and initialize to a value )
    all other variables are not initialized.

******************************************************************

The compiler defaults to the 16F84 architexture.  Use compiler
directives to set up a different device:

#pragma pic  nnn   where nnn is decimal number
  This changes the location of the variable addresses when they are
  declared in C.

#pragma eesize nnn   - size of the EEPROM, otherwise the default is 64

#pragma banksize nnn  - size of the data banks, default is 128
  Most simple devices are 128, 18 series is 256

#pragma bsr   - use if the device has a bsr register.
  The default is no bsr and the RP0 and RP1 bits will be used for banking

#pragma access nnn nnn - an area of memory that is common to all banks
  Specify the start and end in decimal.  Use as many of these as needed
  to define the device.  The default is the 16F84 mapping.  These are
  not needed for the 16F84, but as an example:( don't add the comments )
  #pragma access 0 0       indf register
  #pragma access 2 4      pcl status fsr
  #pragma access 10 11    pclath intcon
  #pragma access 12 79    all of the ram

  Some devices have 16 locations at the top of each page.
  Just define the page zero locations.

  18F devices have two access banks, define these as
  #pragma  access 0 127     access ram
  #pragma  access 3968 4095  registers
  You will want eesize, bsr, and banksize also for 18F devices

*********************************************************************

The above will work for simple devices -  for devices less than 2k code words
and 4 or less banks.  And will work for larger devices if your code fits
in 2k.

*********************************************************************

Advanced considerations:

Interupts - you need to save all resources used
  Save the W reg and STATUS  of course
  Save _temp if shifts or subtracts are used.
    Note some conditionals use subtracts, some use adds.
    The subtracts use _temp because the PIC does subtraction backwards
    from every other micro I have programmed.

  EE reads.  The _eeadr routine as above is not reentrant.  Also EE reads
  rely upon loading registers and setting go bits in a certain order, so you
  really can't interupt the read ( or write ) process and get back to where
  you were.  So options:
     Don't use EE data in the interupt routine.  Simplist.

     Use a #asm and #endasm block to disable interupts before any EE read.

     Or write the _eeadr routine to disable interupts.  It will be tricky or
     impossible to restore the original state of the global interupt for
     this choice. Easy to just disble and re-enable. I didn't write it this way
     because I don't know if you want the interupts enabled at the end of
     every ee read.


Paging and PAGESEL
  If your code is less than 2k, you are all set.

  If not, the runtime routines will need to be replicated at the beginning
  of each 2k page such that they shadow page 0.  You will need to use
  assembly PAGESEL commands where appropriate.

  The interupts if used will need to be handled differently.  This is somewhat
  complicated, but basically if code in page 1 is interupted, it vectors to
  location zero in page 0 ( but the pclath is still pointing to page 1 ).  When
  it jumps, it goes to page 1 - not where one expected in page 0.  There is
  some discussion on the web about different ways to handle this. I intend to
  try a shadow routine,  or don't jump at the vector and relocate the runtime
  to the top of each page. All solutions are quite messy.

Indirect bank selection and BANKISEL
  It didn't seem useful to put un-needed BANKISEL's all over.
  The FSR covers 256 bytes and many devices haven't much more memory.

  Options:  The FSR is used for arrays and pointers. ( structures ? ).
            Some expressions with inc and dec use the FSR

    Put all the array variables in the first 256 bytes.  Simplest.

    Use #asm #endasm block and BANKISEL if it is needed. Be sure to reset
    the bit after.

  The 18F devices have 3 FSR's.  The compler needs one.  Rename whichever
  one you want from FSRnL to just FSR in the definitions.  Also rename the
  INDFn register.  This leaves two free for assembly use.


Function calls.
  Functions can have one argument and it is passed in the W register.
  It is saved in a location of the same name of the function with a
  leading underscore added.  There is no stack, so these variables use
  ram space, unlike normal C function arguments.  It is basically a
  static variable and it is scoped like a static.

C statement form:  x += y;
  Use this form whenever possible.  The PIC instructions support it
  directly.  You will save one instructon each time it is used.
  Unlike what most C books say, it is not the same as x = x + y.



****************************************************************************

A batch file for compile and assembly - mkpic.bat:

rem make file for mcpic
@echo off
if "%1" == "" goto needname
if exist %1.asm copy %1.asm %1.old
echo Compiling...
\mcc\mcpic   %1.c > %1.asm
if errorlevel 1 goto errors
echo Assembling...
rem c:\mpasm\mpasm %1.asm
"c:\Program Files\Microchip\MPASM Suite\MPASMWIN" %1.asm
if errorlevel 0 goto bye
goto serrors

:needname
echo need the filename to compile
goto bye

:errors
echo There were compile errors - See %1.asm
goto bye

:serrors
echo There were assembly errors - See %1.err

:bye

**************************************************************************

An Example:

A complete morse code keyer program showing how to set up a
program.   First the .h file and then the .c follows.
This program uses EEDATA and uses an interupt.  The keyer does not have
an on/off switch, instead using the sleep function.  It has been running
without a reset since 2003 in an Altoids box.  The compiled asm code follows.




/*  pic16f84.h    for pic16f84a micro  */
/*  keyer.h - uses rc clocking */

/*
    mcpic include file
    (c) 1/14/2002   Ron Carr

    set up proper global registers and definitions
*/
#asm

; definitions

F      equ  1           ; declare destination options
W      equ  0

;----- STATUS Bits --------------------------------------------------------

IRP                          EQU     H'0007'
RP1                          EQU     H'0006'
RP0                          EQU     H'0005'
NOT_TO                       EQU     H'0004'
NOT_PD                       EQU     H'0003'
Z                            EQU     H'0002'
DC                           EQU     H'0001'
C                            EQU     H'0000'

;----- INTCON Bits --------------------------------------------------------

GIE                          EQU     H'0007'
EEIE                         EQU     H'0006'
T0IE                         EQU     H'0005'
INTE                         EQU     H'0004'
RBIE                         EQU     H'0003'
T0IF                         EQU     H'0002'
INTF                         EQU     H'0001'
RBIF                         EQU     H'0000'

;----- OPTION_REG Bits ----------------------------------------------------

NOT_RBPU                     EQU     H'0007'
INTEDG                       EQU     H'0006'
T0CS                         EQU     H'0005'
T0SE                         EQU     H'0004'
PSA                          EQU     H'0003'
PS2                          EQU     H'0002'
PS1                          EQU     H'0001'
PS0                          EQU     H'0000'

;----- EECON1 Bits --------------------------------------------------------

EEIF                         EQU     H'0004'
WRERR                        EQU     H'0003'
WREN                         EQU     H'0002'
WR                           EQU     H'0001'
RD                           EQU     H'0000'

;==========================================================================
;
;       RAM Definition
;
;==========================================================================

        __MAXRAM H'CF'
        __BADRAM H'07', H'50'-H'7F', H'87'

;==========================================================================
;
;       Configuration Bits
;
;==========================================================================

_CP_ON                       EQU     H'000F'
_CP_OFF                      EQU     H'3FFF'
_PWRTE_ON                    EQU     H'3FF7'
_PWRTE_OFF                   EQU     H'3FFF'
_WDT_ON                      EQU     H'3FFF'
_WDT_OFF                     EQU     H'3FFB'
_LP_OSC                      EQU     H'3FFC'
_XT_OSC                      EQU     H'3FFD'
_HS_OSC                      EQU     H'3FFE'
_RC_OSC                      EQU     H'3FFF'


       ;declare constants used by the compiler
       list p = 16F84a
       radix  decimal

       ERRORLEVEL -302    ; bank bit warning even when they are correct
                          ; not very useful

       ; change config if needed 
       __config  _RC_OSC & _WDT_OFF & _PWRTE_ON


       ;set up vectors
       org   0          ; reset vector
       call init        ; power up init
_ml    call  main       ; loop
       goto  _ml        ; 
       org   4
       goto  _interupt  ; comment this out if you don't want interupts
                        ; otherwise supply a _interupt() C function

 ; -------------------- run time library  -------------------- */

        ; shifting, shift _temp with count in W
_rshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; unsigned shift, mask bits
        rrf     _temp,F
        addlw   255        ; sub one
        goto    _rshift

_lshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; arithmetic shift
        rlf     _temp,F
        addlw   255        ; sub one
        goto    _lshift

                           ; change when EECON EEDATA are in different
                           ; banks than the 16F84
_eeadr                     ; set up EEDATA to contain desired data
        bcf     STATUS,RP0
        movwf   EEADR      ; correct address in W
        bsf     STATUS,RP0
        bsf     EECON1,RD
        bcf     STATUS,RP0
        movf    EEDATA,W
        movwf   _eedata    ; access ram ( all F84 ram is access ram )
        return

#endasm
                     /* set up page two registers */
#pragma pic 128   
char IND2;
char OPTION_REG;
char PCL2;
char STATUS2;
char FSR2;
char TRISA;
char TRISB;
char _unused2;
char EECON1;
char EECON2;
char PCLATH2;
char INTCON2;

                   /* declare page one registers */
#pragma pic 0

char INDF;
char TMR0;
char PCL;
char STATUS;
char FSR;
char PORTA;
char PORTB;
char _unused;
char EEDATA;
char EEADR;
char PCLATH;
char INTCON;

char _temp;     /* temp location for subtracts and shifts */
char _eedata;   /* and eedata in access ram area  */

/* ------------------- end of shell set up ------------------- */

And then the c program 

/*

   pic keyer
   (C) 2003 Ron Carr

   B port all inputs with pullups enabled
      dah    bit 7
      dit    bit 6

      swap   bit 1
      mode   bit 0

   A port all outputs
      tx enable bit 1
      sidetone  bit 0

*/
  /*
     clock speed and timer count determin sidetone freq and
     keying speed.  Aiming for 800 hz sidetone.
     Think want 400 khz clock and timer value of 64.
     may need to reduce timer value by amount of instructions in interupt
     routine.

     R/C values  R=      C=  
  */

/*
simple commands 
  speed change -
    10  or more dits in a row - increase speed
    10  or more dahs in a row - decrease speed

*/


#include <keyer.h>

#define DAH 128    /* bit 7 on B port */
#define DIT  64    /* bit 6 on B port */
#define MODEA 0
#define MODEB 1    /* bit 0 on B port */

/* intcon values */
#define CHANGE_EN 0x08
#define TIMER_EN  0xa0

/* timer value to load 256 - 64 */
#define TIMEVAL 160

/* eeprom values */
extern char EEDITCOUNT = 72;     /* about 13 wpm */
extern char EEDAHCOUNT = 216;

/* globals */
char cel;    /* current element */
char nel;    /* next element */
char mask;   /* mask for A port, enables tx and sidetone */
char toggle; /* interupt half count, for generating a tone */
char counter; 
char mode;
char swap;      /* swap DIT and DAH port definitions */
char fmask;     /* 1st half el time mask */
char lmask;     /* 2nd half el time mask */

char ditcount;   /* terminal values for counter */
char dahcount;
char halfcount;  /* sample time */
char elcount;

char ttlel;  /* for speed change routine */

/* for interupt temp storage */
char wtemp;
char stemp;

/* set up ports, init key variables */
init(){

   cel= nel= mask= toggle= 0;
   ditcount= EEDITCOUNT;
   dahcount= EEDAHCOUNT;
   PORTA= 0;
   PORTB= 0;
   TRISA= 0;
   TRISB= 0xff;
   OPTION_REG= 0x08;   /* ?may need prescaler 0, maybe not 8 ? */
                       /* pullups are enabled */

}

/* gen side tone and increment a counter */
_interupt(){

/* !!!! check generated code does not use _temp, indirect register,
   shift, or EEPROM reads.  If so then will need to save other data */

   /* save W register, clear interupt status */
#asm
   movwf   wtemp
   swapf   STATUS,W
   movwf   stemp;
#endasm

   INTCON= 0x20;  /* timer enable only, clear int status */

   /* generate the side tone, A port bit 0 */
   toggle ^= 1;
   PORTA= ( toggle + 2 ) & mask;

   /* count at half interupt rate, avoid overflow */
   counter= ( counter == 254 ) ? 254 : counter + toggle;

   TMR0= TIMEVAL;   /* value to count from */

   /* restore W register */
#asm
   swapf  stemp,W
   movwf  STATUS
   swapf  wtemp,F
   swapf  wtemp,W
#endasm


}    /* return enables interupts */



/* loops via the .h code */
main(){

/*
 code needs to handle
    bounces on the contacts
    nothing to do ( on powerup probably no paddle is closed )
*/
   /* start up counter interupts */
   INTCON= TIMER_EN;

   cel= readpdl();     /* we wokeup, get which paddle */
   mode= PORTB & 1;    /* 0 mode A, 1 mode B */
   /* swap- xor of zero gives normal operation, xor 192 swaps.
      ie   128 ^ 192 == 64.   64 ^ 192 == 128  ( dit+dah = 192 ) */
   swap= ( PORTB & 2 ) ? 0 : DIT + DAH;  /* 0 swap dit and dah, hi normal */
                                 /* speed change reversed if swap is used */
   while( cel ){

      if( cel == (DIT + DAH) ) cel= DIT;  /* dit wins if ever a tie */

      elcount = ((cel ^ swap) == DAH) ? dahcount: ditcount;
      mask= 3;            /* enable tx and sidetone */
      fmask= counter= 0;
      lmask= (DIT + DAH) - cel;   /* sample opposite only 2nd half */ 
      if( mode == MODEA && readpdl() == ( DIT + DAH ) ) lmask= 0;
      wait4it();   

      counter= mask= 0;   /* send space */
      elcount= ditcount;
      fmask= lmask;       /* continue with selected sample type for */
      wait4it();          /* the complete element space time */

      /* last sample */
      if( nel == 0 ) nel= readpdl();
      /* toggle may be needed for mode A iambic */
      if( nel == ( DIT + DAH ) ) nel-= cel;

      /* speed change routine */
      if( cel == nel ) ++ttlel;
      else ttlel= 0;
      if( ttlel >= 10 ) speedchange(cel);

      cel= nel;  nel= 0;   /* send whatever in queue */

      }   /* end something to send */

   /* wait short time for more contacts on switches,
      also if switch bounces, we will catch the contact here */
   /* could provide other functions on Bport with switches
      and read them here instead of calling readpdl */
   counter= 0;
   while( counter < EEDAHCOUNT ){
      if( readpdl() ) return; /* re-enters main(), skips sleep */
      }

   /*
   nothing happening so power down
   sleep with just port b change enabled, global interupt disabled
   just wakes up, no branch to interupt code
   */
   INTCON= CHANGE_EN;
#asm
   sleep
   nop
   nop
#endasm

/*   INTCON= 0; */    /*(redundant) disable ints,clear change bit */

}  /* loops via .h code back to main() */


char readpdl(){

   return ( PORTB ^ 0xff ) & ( DIT + DAH );
}

/*
 wait for element to be sent
   sample paddles - mode B
      sample other paddle anytime after half element sent
      sample same paddle after space sent

   mode A
      both closed at start --> only sample both at end of space
         and toggle if still have both.
      else same as mode B

*/
wait4it(){


   halfcount= elcount >> 1;

   while( counter < elcount ){

      if( nel == 0 ){
         nel= readpdl(); 
         if( counter >= halfcount ) nel &= lmask;
         else nel &= fmask;         
         }

      }   /* end while */

}

speedchange( char updown ){

   if( updown == DIT ){
      --ditcount;
      dahcount-= 3;
      }
   else{
      ++ditcount;
      dahcount+= 3;
      }
   /* overflow ? */
   if( dahcount < 30 || dahcount >= 254 ){
       ditcount= EEDITCOUNT;
       dahcount= EEDAHCOUNT;
       }

}


*************************************************************************
The compiled code ready to be assembled



; # include < keyer . h > 
; # asm 

; definitions

F      equ  1           ; declare destination options
W      equ  0

;----- STATUS Bits --------------------------------------------------------

IRP                          EQU     H'0007'
RP1                          EQU     H'0006'
RP0                          EQU     H'0005'
NOT_TO                       EQU     H'0004'
NOT_PD                       EQU     H'0003'
Z                            EQU     H'0002'
DC                           EQU     H'0001'
C                            EQU     H'0000'

;----- INTCON Bits --------------------------------------------------------

GIE                          EQU     H'0007'
EEIE                         EQU     H'0006'
T0IE                         EQU     H'0005'
INTE                         EQU     H'0004'
RBIE                         EQU     H'0003'
T0IF                         EQU     H'0002'
INTF                         EQU     H'0001'
RBIF                         EQU     H'0000'

;----- OPTION_REG Bits ----------------------------------------------------

NOT_RBPU                     EQU     H'0007'
INTEDG                       EQU     H'0006'
T0CS                         EQU     H'0005'
T0SE                         EQU     H'0004'
PSA                          EQU     H'0003'
PS2                          EQU     H'0002'
PS1                          EQU     H'0001'
PS0                          EQU     H'0000'

;----- EECON1 Bits --------------------------------------------------------

EEIF                         EQU     H'0004'
WRERR                        EQU     H'0003'
WREN                         EQU     H'0002'
WR                           EQU     H'0001'
RD                           EQU     H'0000'

;==========================================================================
;
;       RAM Definition
;
;==========================================================================

        __MAXRAM H'CF'
        __BADRAM H'07', H'50'-H'7F', H'87'

;==========================================================================
;
;       Configuration Bits
;
;==========================================================================

_CP_ON                       EQU     H'000F'
_CP_OFF                      EQU     H'3FFF'
_PWRTE_ON                    EQU     H'3FF7'
_PWRTE_OFF                   EQU     H'3FFF'
_WDT_ON                      EQU     H'3FFF'
_WDT_OFF                     EQU     H'3FFB'
_LP_OSC                      EQU     H'3FFC'
_XT_OSC                      EQU     H'3FFD'
_HS_OSC                      EQU     H'3FFE'
_RC_OSC                      EQU     H'3FFF'


       ;declare constants used by the compiler
       list p = 16F84a
       radix  decimal

       ERRORLEVEL -302    ; bank bit warning even when they are correct
                          ; not very useful

       ; change config if needed - xtal osc for now
       __config  _RC_OSC & _WDT_OFF & _PWRTE_ON


       ;set up vectors
       org   0          ; reset vector
       call init        ; power up init
_ml    call  main       ; loop
       goto  _ml        ; 
       org   4
       goto  _interupt  ; comment this out if you don't want interupts
                        ; otherwise supply a _interupt() C function

 ; -------------------- run time library  -------------------- */

        ; shifting, shift _temp with count in W
_rshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; unsigned shift, mask bits
        rrf     _temp,F
        addlw   255        ; sub one
        goto    _rshift

_lshift
        btfsc   STATUS,Z    
        return             ; ret if shift amount is zero
        bcf     STATUS,C   ; arithmetic shift
        rlf     _temp,F
        addlw   255        ; sub one
        goto    _lshift

_eeadr                     ; set up EEDATA to contain desired data
        bcf     STATUS,RP0
        movwf   EEADR      ; correct address in W
        bsf     STATUS,RP0
        bsf     EECON1,RD
        bcf     STATUS,RP0
        movf    EEDATA,W
        movwf   _eedata
        return

QUR1
; # pragma pic 128 
; char IND2 ; 
	;data
IND2	equ 128
; char OPTION_REG ; 
OPTION_REG	equ 129
; char PCL2 ; 
PCL2	equ 130
; char STATUS2 ; 
STATUS2	equ 131
; char FSR2 ; 
FSR2	equ 132
; char TRISA ; 
TRISA	equ 133
; char TRISB ; 
TRISB	equ 134
; char _unused2 ; 
_unused2	equ 135
; char EECON1 ; 
EECON1	equ 136
; char EECON2 ; 
EECON2	equ 137
; char PCLATH2 ; 
PCLATH2	equ 138
; char INTCON2 ; 
INTCON2	equ 139
; # pragma pic 0 
; char INDF ; 
INDF	equ 0
; char TMR0 ; 
TMR0	equ 1
; char PCL ; 
PCL	equ 2
; char STATUS ; 
STATUS	equ 3
; char FSR ; 
FSR	equ 4
; char PORTA ; 
PORTA	equ 5
; char PORTB ; 
PORTB	equ 6
; char _unused ; 
_unused	equ 7
; char EEDATA ; 
EEDATA	equ 8
; char EEADR ; 
EEADR	equ 9
; char PCLATH ; 
PCLATH	equ 10
; char INTCON ; 
INTCON	equ 11
; char _temp ; 
_temp	equ 12
; char _eedata ; 
_eedata	equ 13
; # define DAH 128 
; # define DIT 64 
; # define MODEA 0 
; # define MODEB 1 
; # define CHANGE_EN 0x08 
; # define TIMER_EN 0xa0 
; # define TIMEVAL 160 
; extern char EEDITCOUNT = 72 ; 

; ; extern char EEDAHCOUNT = 216 ; 

; ; char cel ; 
cel	equ 14
; char nel ; 
nel	equ 15
; char mask ; 
mask	equ 16
; char toggle ; 
toggle	equ 17
; char counter ; 
counter	equ 18
; char mode ; 
mode	equ 19
; char swap ; 
swap	equ 20
; char fmask ; 
fmask	equ 21
; char lmask ; 
lmask	equ 22
; char ditcount ; 
ditcount	equ 23
; char dahcount ; 
dahcount	equ 24
; char halfcount ; 
halfcount	equ 25
; char elcount ; 
elcount	equ 26
; char ttlel ; 
ttlel	equ 27
; char wtemp ; 
wtemp	equ 28
; char stemp ; 
stemp	equ 29
; init ( ) { 
	;code
init
; cel = nel = mask = toggle = 0 ; 
	movlw	0
	movwf	toggle
	movwf	mask
	movwf	nel
	movwf	cel
; ditcount = EEDITCOUNT ; 
	movlw	0
	call	_eeadr
	movf	_eedata,W
	movwf	ditcount
; dahcount = EEDAHCOUNT ; 
	movlw	1
	call	_eeadr
	movf	_eedata,W
	movwf	dahcount
; PORTA = 0 ; 
	movlw	0
	BANKSEL	PORTA
	movwf	PORTA
; PORTB = 0 ; 
;movlw	0
	clrf 	PORTB
; TRISA = 0 ; 
	movlw	0
	bsf	STATUS,RP0
	movwf	TRISA
; TRISB = 0xff ; 
	movlw	255
	movwf	TRISB
; OPTION_REG = 0x08 ; 
	movlw	8
	movwf	OPTION_REG
	return
; } 
; _interupt ( ) { 
_interupt
; # asm 
   movwf   wtemp
   swapf   STATUS,W
   movwf   stemp;
QUR2
; INTCON = 0x20 ; 
	movlw	32
	movwf	INTCON
; toggle ^= 1 ; 
	movlw	1
	xorwf	toggle,F
; PORTA = ( toggle + 2 ) & mask ; 
	movf	toggle,W
	addlw	2
	andwf	mask,W
	BANKSEL	PORTA
	movwf	PORTA
; counter = ( counter == 254 ) ? 254 : counter + toggle ; 
	movf	counter,W
	addlw	2
	btfss	STATUS,Z
	goto	QUR3
	movlw	254
	iorlw	0
	goto	QUR4
QUR3
	movf	counter,W
	addwf	toggle,W
QUR4
	movwf	counter
; TMR0 = 160  ; 
	movlw	160
	BANKSEL	TMR0
	movwf	TMR0
; # asm 
   swapf  stemp,W
   movwf  STATUS
   swapf  wtemp,F
   swapf  wtemp,W
QUR5
	retfie
; } main ( ) { 
main
; INTCON = 0xa0  ; 
	movlw	160
	movwf	INTCON
; cel = readpdl ( ) ; 
	call	readpdl
	movwf	cel
; mode = PORTB & 1 ; 
	BANKSEL	PORTB
	movf	PORTB,W
	andlw	1
	movwf	mode
; swap = ( PORTB & 2 ) ? 0 : 64  + 128  ; 
	movf	PORTB,W
	andlw	2
	btfsc	STATUS,Z
	goto	QUR6
	movlw	0
	iorlw	0
	goto	QUR7
QUR6
	movlw	192
	iorlw	0
QUR7
	movwf	swap
; while ( cel ) { 
QUR8
	movf	cel,W
	btfsc	STATUS,Z
	goto	QUR9
; if ( cel == ( 64  + 128  ) ) cel = 64  ; 
	movf	cel,W
	addlw	64
	btfss	STATUS,Z
	goto	QUR10
	movlw	64
	movwf	cel
; elcount = ( ( cel ^ swap ) == 128  ) ? dahcount : ditcount ; 
QUR10
	movf	cel,W
	xorwf	swap,W
	addlw	128
	btfss	STATUS,Z
	goto	QUR11
	movf	dahcount,W
	goto	QUR12
QUR11
	movf	ditcount,W
QUR12
	movwf	elcount
; mask = 3 ; 
	movlw	3
	movwf	mask
; fmask = counter = 0 ; 
	movlw	0
	movwf	counter
	movwf	fmask
; lmask = ( 64  + 128  ) - cel ; 
	movlw	192
	movwf	_temp
	movf	cel,W
	subwf	_temp,W
	movwf	lmask
; if ( mode == 0  && readpdl ( ) == ( 64  + 128  ) ) lmask = 0 ; 
	movf	mode,W
;addlw	256
	btfss	STATUS,Z
	goto	QUR13
	call	readpdl
	addlw	64
	btfss	STATUS,Z
	goto	QUR13
;movlw	0
	clrf 	lmask
; wait4it ( ) ; 
QUR13
	call	wait4it
; counter = mask = 0 ; 
	movlw	0
	movwf	mask
	movwf	counter
; elcount = ditcount ; 
	movf	ditcount,W
	movwf	elcount
; fmask = lmask ; 
	movf	lmask,W
	movwf	fmask
; wait4it ( ) ; 
	call	wait4it
; if ( nel == 0 ) nel = readpdl ( ) ; 
	movf	nel,W
;addlw	256
	btfss	STATUS,Z
	goto	QUR14
	call	readpdl
	movwf	nel
; if ( nel == ( 64  + 128  ) ) nel -= cel ; 
QUR14
	movf	nel,W
	addlw	64
	btfss	STATUS,Z
	goto	QUR15
	movf	cel,W
	subwf	nel,F
; if ( cel == nel ) ++ ttlel ; 
QUR15
	movf	cel,W
	movwf	_temp
	movf	nel,W
	subwf	_temp,W
	btfss	STATUS,Z
	goto	QUR16
	incf	ttlel,F
; else ttlel = 0 ; 
	goto	QUR17
QUR16
	movlw	0
	movwf	ttlel
QUR17
; if ( ttlel >= 10 ) speedchange ( cel ) ; 
	movf	ttlel,W
	addlw	246
	btfss	STATUS,C
	goto	QUR18
	movf	cel,W
	call	speedchange
; cel = nel ; nel = 0 ; 
QUR18
	movf	nel,W
	movwf	cel
;movlw	0
	clrf 	nel
; } 
	goto	QUR8
QUR9
; counter = 0 ; 
;movlw	0
	clrf 	counter
; while ( counter < EEDAHCOUNT ) { 
QUR19
	movf	counter,W
	movwf	_temp
	movlw	1
	call	_eeadr
	movf	_eedata,W
	subwf	_temp,W
	btfsc	STATUS,C
	goto	QUR20
; if ( readpdl ( ) ) return ; 
	call	readpdl
	iorlw	0
	btfsc	STATUS,Z
	goto	QUR21
	return
; } 
QUR21
; } INTCON = 0x08  ; 
	goto	QUR19
QUR20
	movlw	8
	movwf	INTCON
; # asm 
   sleep
   nop
   nop
QUR22
	return
; } char readpdl ( ) { 
readpdl
; return ( PORTB ^ 0xff ) & ( 64  + 128  ) ; 
	BANKSEL	PORTB
	movf	PORTB,W
	xorlw	255
	andlw	192
	return
; } 
; wait4it ( ) { 
wait4it
; halfcount = elcount >> 1 ; 
	movf	elcount,W
	movwf	_temp
	movlw	1
	call	_rshift
	movf	_temp,W
	movwf	halfcount
; while ( counter < elcount ) { 
QUR23
	movf	counter,W
	movwf	_temp
	movf	elcount,W
	subwf	_temp,W
	btfsc	STATUS,C
	goto	QUR24
; if ( nel == 0 ) { 
	movf	nel,W
;addlw	256
	btfss	STATUS,Z
	goto	QUR25
; nel = readpdl ( ) ; 
	call	readpdl
	movwf	nel
; if ( counter >= halfcount ) nel &= lmask ; 
	movf	counter,W
	movwf	_temp
	movf	halfcount,W
	subwf	_temp,W
	btfss	STATUS,C
	goto	QUR26
	movf	lmask,W
	andwf	nel,F
; else nel &= fmask ; 
	goto	QUR27
QUR26
	movf	fmask,W
	andwf	nel,F
QUR27
; } 
; } 
QUR25
; } } 
	goto	QUR23
QUR24
	return
; speedchange ( char updown ) { 
	;data
_speedchange	equ	30
	;code
speedchange
	movwf	_speedchange
; if ( updown == 64  ) { 
	movf	_speedchange,W
	addlw	192
	btfss	STATUS,Z
	goto	QUR28
; -- ditcount ; 
	decf	ditcount,F
; dahcount -= 3 ; 
	movlw	3
	subwf	dahcount,F
; } 
; else { 
	goto	QUR29
QUR28
; ++ ditcount ; 
	incf	ditcount,F
; dahcount += 3 ; 
	movlw	3
	addwf	dahcount,F
; } 
QUR29
; if ( dahcount < 30 || dahcount >= 254 ) { 
	movf	dahcount,W
	addlw	226
	btfss	STATUS,C
	goto	QUR30
	movf	dahcount,W
	addlw	2
	btfss	STATUS,C
	goto	QUR31
QUR30
; ditcount = EEDITCOUNT ; 
	movlw	0
	call	_eeadr
	movf	_eedata,W
	movwf	ditcount
; dahcount = EEDAHCOUNT ; 
	movlw	1
	call	_eeadr
	movf	_eedata,W
	movwf	dahcount
; } 
; } 
QUR31
	return
	org	0x2100	;eeprom constant data
	de	72
	de	216
	end
