#include <pic16f84.h>

#define BIT 6


_interupt(){

}

char i,j,k;

#pragma banksize 128
/* #pragma bsr */
#pragma access 0 0
#pragma access 2 4
#pragma access 10 79

extern char ee = 4;

char b2[1];


main(){


 i = 5;
 j = 7;


if( i > 88 || j == 7)  k+= ( i & j);

if( i > 5 ||  j < 5 ) ++k;

i = 1 << BIT;

}
