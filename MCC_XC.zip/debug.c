

/*  mc80 ignores immediate val in function call */
/*  only seems to fail when register is also in call as another arg */
char t2;
test(char cc, char dd){
char t1;
/* this should be valid */
/* cc is suppressed as in c already
   t1 is in e reg and mov'd to b
   const 19 should load into e */
     call(cc,t1,19);
}
