/* dummy file for naming the exe file as mc26 */



