/* 
   scan a dsk list file and fix up the function addresses in the
   symbol table
*/


#include <stdio.h>
#include <string.h>



FILE *in1, *in2;   /* 2 input files */
                   /* output is to stdout */

/* main argument is name of the lst file */

main(int argc, char * argv[]){
char *p1,*p2,temp[60];
char *q1,temp2[512];
char name[20];
int i;
unsigned int ps;

   /* open the files */

   if( (in1= fopen("$temp.sym","r")) == 0 ){
      printf("Can't open $temp.sym\n");
      exit(1);
      }

   if( argc < 2 ){
      printf("Need filename on command line\n");
      exit(1);
      }


   if( (in2= fopen(argv[1],"r")) == 0){
      printf("Can't open %s\n",argv[1]);
      exit(1);
      }

   printf("#asm\n");
   while( p1= fgets(temp,60,in1 )){
      if( p2= strstr(temp,"????")){  /* find and make the sub */
   
         rewind( in2 );

         name[0]= '\t';
         for( i= 1; i < 18; ++i ){  /* form the name to search for */
            if( p1[i] != ' ') name[i]= p1[i];
            else break;
            }
         name[i++]= ':';    name[i]= 0;

         while( q1= fgets(temp2,512,in2)){
            if( strstr(temp2,name)){
               for( i= 7; i < 11; ++i ){    /* make substitution */
                  *p2++= q1[i];
                  }
               ++p1;   /* skip the leading ; comment */
               break;
               }
            }   /* end while file 2 */
         }

      printf("%s",p1);
      }   /* end while file 1 */

   /* now scan file two again for the .ps statement */
   /* we want the last one in the file */
   rewind(in2);

   while( q1= fgets(temp2,512,in2)){
      if( q1[5] == '0' ) sscanf(&q1[7],"%x",&ps);
      }
/* add two in case last instuction has an argument */
   printf("      .ps   0%xh\n",ps+2);

/* end asm bug - leave off on end of include file   
   printf("#endasm\n");
*/
   fclose(in2);
   fclose(in1);
}
