/* symbol table routines */


#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <string.h>
#include "mcsym.h"
#include "mcc.h"
#include "mcvar.h"
#include "mcout.h"
#include "mcexp.h"


#define TABLESIZE 1000

extern char word[];
extern int label;
extern char hash[];
 int errcount;

/* symbol table pointer storage */

static struct SYMBOL *table[TABLESIZE];

static int last;          /* last index to the table */
/* stackoff was static, changed for pic */
unsigned int stackoff;   /* offset of function arg and stack args */
unsigned int gaddress;   /* for C26 paging */
unsigned int eaddress;   /* for PIC eeprom ( externs ) */

/* macro table */

#define MACSIZE 300

/* macro is two stings that are stored together */
char *mactable[MACSIZE];

void findmac(){  /* subsitute macro for word */
int i;
extern char preword[];
char *p;

 i= 0;
 while( mactable[i] ){
    if( strcmp( mactable[i], preword ) == 0 ){
       p= mactable[i];
       while( *p++ );        /* skip first word */
       strcpy( preword,p );     /* make substitution */
       return;
       }
    ++i;
    }
}

void putmac(){  /* store a macro definition */
char temp[120];
int i, j, len;
extern char *lp;
extern next();
extern char word[];

  i= 0;
  next();
  while( mactable[i] ){    /* look for duplicates */

     if( strcmp( mactable[i], word ) == 0){
        error("Duplicate macro definition");
        *lp= '\n';   /* kill rest of the line */
        return;
        }

     ++i;    /* find empty index also */
     }

  if( i == MACSIZE ){
     error("Macro table full");
     return;
     }

  /* make the string */
  strcpy( temp, word );
  len= strlen( temp ) + 1 ;

  /* store new def on the end of temp */

  while( *lp ) temp[len++]= *lp++;    /* need to keep lp at end of line */
  temp[len++]= 0;                     /* need len at 1 more than index */

  mactable[i]=  ( char * )  malloc( len );
  if( mactable[i] == 0 ){
     error("Out of memory in addmac");
     return;
     }

   /* store the string, can't use strcpy because have two strings
       that are seperated by a zero */
  for( j= 0; j < len; j++ ) mactable[i][j]= temp[j];

  next();
  if( lp ) unnext();
}



/* error routine */
void error( char *p ){
int i;
extern int ccount, lcount;
extern char line[];

 printf("\n%s\n",line);
 for( i= 0; i < ccount; i++ ) putchar(' ');
 putchar('^');
 printf("\nLine %d - %s\n",lcount,p);
 if( ++errcount > 10 ) exit(1);

}



void mark(){     /* mark a start of block in table */
struct SYMBOL m;

   clear( &m );
   m.ident= MARK;
   addsym( &m );


}

void release(){  /* remove entries to last mark */
int i;
int ident;
int size;

   size= stackoff;
   i= last - 1;
   while( last > 0 ){
      ident= table[i]->ident;
      if( table[i]->scope == AUTO ){
         /* adjust the stack arg offset */
         stackoff= table[i]->offset;
         }
      free( table[i] );
      --i; --last;
      if( ident == MARK ) break;
      }

   rel( size - stackoff );     /* gen code to release auto space */

}

void fun_end(){  /* remove any FARG's from the table */
int i;
extern int funactive;
extern int shortfun;

  if( funactive ) funactive= 2;     /* flag end in progress */
  i= last - 1;
  while( last > 0 ){
    if( table[i]->scope != FARG ) break;
    free( table[i] );
    --i;  --last;
    }
  /* reset the stack offset to zero */
  stackoff= 0;
  if( funactive ){
     preturn();
     dumplit();      /* output any string literals */
     shortfun= 0;    /* clear this flag here */
     }
}


/* find next entry in table if we have a pointer */
struct SYMBOL *nextvar( struct SYMBOL *p ){
int i;

   for( i= 0; i < last; i++ ){
      if( table[i] == p ) break;
      }
   /* get next one */
   return table[++i];
}

      /* add a symbol */
struct SYMBOL *addsym( struct SYMBOL *ps ){
struct SYMBOL *p;
extern int label;
extern int pic;

 if( last == TABLESIZE ){
    error("Symbol table full");
    return ( struct SYMBOL * ) 0;
    }

 p=  ( struct SYMBOL * )  malloc( sizeof( struct SYMBOL) );
 if( p == 0 ){
   error("Symbol table full");
   return p;
   }
 strcpy( p->name,ps->name);
 p->scope= ps->scope;
 p->type = ps->type;
 p->ident= ps->ident;
 p->indirect= ps->indirect;
 p->sign= ps->sign;
 p->size= ps->size;
 p->size2= ps->size2;
 p->link= ps->link;
 p->offset= ps->offset;



 /* figure offset for static class - make name a hash label */
 if( p->scope == STATIC ){
    p->offset= label++;
    }

 /* figure the offset for FARG's and auto class */
 if( p->scope == FARG || p->scope == AUTO ){
    p->offset= stackoff;
    stackoff+= size( p );
    }

 /* figure the global address for C26 paging */
 if( ( p->scope == GLOBAL || p->scope == STATIC ) &&
     ( p->ident == VAR || p->ident == POINTER || p->ident == ARRAY ||
       p->ident == STRUCT ) ){
    p->address= gaddress;
 /*   gaddress+= size( p );  size is figured in mc26out */
    }

 /* set a bogus address for externs */
 if(  p->scope == EXTERN  ){
    if( pic == 0 ) p->address= -1;
    else p->address= eaddress;
    }

 table[last]= p;
 ++last;
 return p;
}


struct SYMBOL *findsym( char *name2 ){
int i;

 if( *name2 != '$' ){   /* ignore special name */
 /* search table from back to find locals first */
    for( i= last - 1;  i >= 0; --i){
       if( strcmp( table[i]->name, name2 ) == 0 &&
           table[i]->scope != MEMBER ) return table[i];
       }
    }
 return (struct SYMBOL *) 0;
}


void clear( struct SYMBOL *sym ){


  sym->scope= sym->type= sym->indirect= sym->size= sym->size2=
           sym->sign=  sym->ident= sym->offset= sym->name[0]= 0;
  sym->address= 0;
  sym->link= ( void * ) 0;

}


int size_struct( struct SYMBOL * p ){  /* find the size of structure */
int i, sz;
struct SYMBOL * sd;

   /*  first find the definition */
   for( i= 0; i < last; i++ ){
     sd= table[i];
     if( p->link == sd ) break;
     }

 /* size is value of last offset + size of last member */

   sz= 0;
   while( i < last ){       /* find the end */
     if( table[i]->ident == ENDDEF && table[i]->link == sd ) break;
     i++;
     }

   --i;   /* point to last member */

   if( p == table[i] ){
      error("Recursive definition");
      return 0;
      }

   sz= table[i]->offset + size( table[i] );


return sz;
}



int findenddef(i) {  /* find the matching enddef */
struct SYMBOL *def;

  def= table[i];
  while( ++i < last ){
     if( table[i]->ident == ENDDEF && table[i]->link == def ) return i;
     }

  error("Internal error - ENDDEF not found");
  exit(1);
  return 0;
}

/* size union is size of largest member */
int size_union( struct SYMBOL *p ){

int i, sz, sz2;
struct SYMBOL * sd;

   /*  first find the definition */
   for( i= 0; i < last; i++ ){
     sd= table[i];
     if( p->link == sd ) break;
     }

   sz= 0;
   while( ++i < last ){    /* search through definition */
     if( table[i]->ident == ENDDEF && table[i]->link == sd ) break;
     if( table[i]->ident == DEF ){     /* nested definitions */
        i= findenddef( i );
        continue;
        }
     if( p == table[i] ){
        error("Recursive definition");
        return 0;
        }
     sz2= size( table[i] );
     if(sz2 > sz) sz= sz2;
     }

   return sz;
}


  /* report the name of the desired variable in table */
char * findname( struct SYMBOL *p ){
extern char hash[];
static char name[20];

   if( p->scope == STATIC ){
      sprintf(name,"%s%d",hash,p->offset);
      }

   else{   /* default is global name */
      strcpy(name,&p->name);
      }

return name;    /* pointer to static var */
}

/* string literals routines */

static int litcount;
static struct SLIT littable[500];

char * addlit(){   /* store a string literal */
char temp[20];
char *p;


   p= ( char * ) malloc( strlen( word ) + 1 );
   if( p ){
      littable[litcount].lit= p;
      strcpy( p, word );
      }
   else error("Out of Memory");

   sprintf(temp,"%s%d",hash,label++);    /* form the label */
   p=  ( char * ) malloc( strlen(temp) + 1 );
   if( p ){
      littable[litcount].label= p;
      strcpy( p, temp );
      }
   else error("Out of Memory");

   if( ++litcount == 500 ){
      error("Out of Literal space");
      exit( 1 );
      }

   return p;    /* return a pointer to the name */
}


void dumplit(){   /* print out all stored literals */
int i;

   for( i= 0; i < litcount; i++ ){
      dsect();
      plabel( littable[i].label );
      outlit( littable[i].lit );
      free( littable[i].label );
      free( littable[i].lit );
      }
   litcount= 0;
}


void copysymbol( struct SYMBOL *d, struct SYMBOL *s ){

  strcpy( d->name,s->name );
  d->scope= s->scope;
  d->ident= s->ident;
  d->type= s->type;
  d->indirect= s->indirect;
  d->sign= s->sign;
  d->size= s->size;
  d->size2= s->size2;
  d->offset= s->offset;
  d->link= s->link;
  d->address= s->address;

}


void findmember( struct EVAL *e1 ){
struct SYMBOL *p;
struct SYMBOL *skip;

   if( e1->var.link != 0 ){
      p= e1->var.link;
      while(  p= nextvar( p ) ){
         if( p->ident == ENDDEF && p->link == e1->var.link ) break;

         /* skipping of nested structures */
         if( p->ident == DEF ){
            skip= p;
            while( p= nextvar(p) ){
               if( p->ident == ENDDEF && p->link == skip ) break;
               }
            continue;
            }

         if( match( &p->name ) ){   /* found it */
            e1->var.ident= p->ident;
            e1->var.type= p->type;
            e1->var.indirect= p->indirect;
            e1->var.sign= p->sign;
            e1->var.size= p->size;
            e1->var.size2= p->size2;
            e1->var.offset= p->offset;
            e1->var.link= p->link;
     /* correct address is already loaded from copysymbol ?? */
      /* gets garbage      e1->var.address= p->address; */
            return;
            }

         }

   }

   error("Not a member of struct or union");

}



void dumpexterns(){    /* list the external function names */
int i;
struct SYMBOL *p;
FILE *fp;

  for( i= 0; i < last; i++ ){
     p= table[i];
     if( p->scope == EXTERN && p->ident == FUNCTION ) pextern( &p->name );
     }

/* dump out a symbol file */
  fp=fopen("$temp.sym","w");

  for( i= 0; i < last; ++i ){
     p= table[i];

     if( ( p->scope == GLOBAL ) &&
         ( p->ident == VAR || p->ident == POINTER || p->ident == ARRAY ||
           p->ident == STRUCT ) ){
        fprintf(fp,"%s   .set  0%xh\n",findname(p),p->address);
        }

   /* print out global function names  - need another program to
      fix these up from data in the assembly listing  */

     if( p->scope == GLOBAL  && p->ident == FUNCTION ){
        fprintf(fp,";%s   .set  0????h\n",findname(p));
        }

     }
  fprintf(fp,"      .ds  0%xh\n",gaddress);

  fclose(fp);

}
