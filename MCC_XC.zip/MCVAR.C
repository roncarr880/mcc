#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#include "mcsym.h"
#include "mcc.h"
#include "mcvar.h"
#include "mcout.h"
#include "mcexp.h"


extern char word[];
extern char *lp;
extern int funactive;
extern int label;
extern char hash[];


struct SYMBOL * do_struct( struct SYMBOL *ps, char *tag );
struct SYMBOL * var( struct SYMBOL *p );
void  old_fun( struct SYMBOL *p );
int arrayinit( struct SYMBOL *p );
void varinit( struct SYMBOL *p );
void pointerinit( struct SYMBOL *p );
void structinit( struct SYMBOL *p );


void structinit( struct SYMBOL *v ){
/* called from varinit - block has been done */
struct SYMBOL *mbr;

   /* sequence through members */
   mbr= v->link;  /* get definition */
   if( mbr ){     /* always should be true */
      while( 1 ){
         mbr= nextvar( mbr );    /* next member */
         if(mbr->ident == ENDDEF && mbr->link == v->link ) break;
         if( mbr->scope != MEMBER ) continue;
         if( *lp == ',' ) next();
         switch( mbr->ident ){
            case VAR:      varinit( mbr );  break;
            case ARRAY:  arrayinit( mbr );  break;
            case POINTER: pointerinit( mbr ); break;
            }
         }
      }
   else error("Undefined structure");

}



void varinit( struct SYMBOL *v ){   /* simple variable init */
int block;
long val;
int s;

  block = 0;
  if( *lp == '{' ){
     next();
     block= 1;
     }

  if( v->type == STRUCT ) structinit( v );

  else{           /* simple var */
     s= size(v);
     next();
     val= const_exp();
     dbytes( val, s );
     }

  if( block ){
     if( *lp != '}' ) error("Missing bracket");
     next();
     }

}

void pointerinit(  struct SYMBOL *v ){
int block;
char *p;

  v= v;              /* ****  passed argument is not used **** */

  block = 0;
  if( *lp == '{' ){
     next();
     block= 1;
     }

  if( *lp == '"' ) { /* a pointer to string lit */
     next();
     p= addlit();
     dw( p );
     }

  else{      /* need to identify type of expression ***** */
/* assume decimal numbers, simple names for now */
     next();
     dw( word );
     }

  if( block ){
     if( *lp != '}' ) error("Missing bracket");
     next();
     }
}


int arrayinit( struct SYMBOL *v ){
int block;
int count, s, s2;
struct SYMBOL v2;

 /* not pointers and string literal  */
  if( v->indirect == 0 && v->type == CHAR ){
     if( *lp == '"' ){   /* its a string literal */
        next();
        count= outlit(word);
        pad( v->size - count );
        return count;
        }
      }

  count= block = 0;
  if( *lp == '{' ){
     next();
     block= 1;
     }

  clear( & v2 );

/* make a single element */
  v2.scope= v->scope;
  v2.type= v->type;
  v2.link= v->link;

  if( v->size2 ){         /* its an 2d array */
     s2= v->size2;
     v2.size2= 0;
     v2.size= v->size;

     /* init each part of the double array */
     while( s2-- ){
        if( *lp == ',' ) next();
        if( *lp != ';' ) arrayinit( &v2 );
        else pad( size( &v2 ));
        }

     if( block ){
        if( *lp != '}' ) error("Missing bracket");
        next();
        }
     return 0;
     }


  else if( v->indirect ){
     v2.ident= POINTER;
     }
  else v2.ident= VAR;

  s2= v->size;        /* don't do more than its size */
  /* code here */
  while( 1 ){
     ++count;
     switch( v2.ident ){
        case VAR:      varinit( &v2 );      break;
        case POINTER:  pointerinit( &v2 );  break;
        }
     if( *lp != ',' ) break;
     if( s2 && s2 == count ) break;
     next();
     }

  s= sizeone( v );
  pad( s * ( v->size - count ) );

  if( block ){
     if( *lp != '}' ) error("Missing bracket");
     next();
     }
  return count;
}



void allocate( struct SYMBOL *v ){  /* allocate storage for vars */
int count;
extern int pic;

  if( ( v->scope == GLOBAL  || v->scope == STATIC  ||
        (  pic  && v->scope == EXTERN )     )  &&
      ( v->ident == VAR || v->ident == POINTER || v->ident == ARRAY ) ){

      dsect();

      if( v->scope == EXTERN ) pic= 2;  /* flag for change */
      else {
         plabel( findname(v) );
         }

      if( *lp != '=' ){  /* no initial value given */
         ds(size(v));
         }

      else{    /* an initial value is specified */
         next();
         switch( v->ident ){
            case VAR:
               varinit( v );    /* simple init */
               break;

            case ARRAY:
               count= arrayinit( v );
               if( v->size == 0 ) v->size= count;
               break;

            case POINTER:
               pointerinit( v );
               break;


            } /* end switch */
         }  /* end initial values */

     dumplit();
     if( pic == 2 ) pic= 1; 
     }  /* end if global or static */

 if( v->scope == AUTO ){
     stackvar( size( v ));
     }

}


/* enter a variable name into table */

struct SYMBOL * var( struct SYMBOL *ps ){
struct SYMBOL *p;
int d;

     p= 0;
     /* entered with type defined or not */
     if( ps->type == 0 ){
        if( (d= type() ) != 0 )  ps->type= d , next() ;
        else ps->type= INT;  /* default type */
        }

     if( ps->ident == 0 ) ps->ident= VAR;

     while( match("*") ){
        ps->indirect+= 1;
        next();
        ps->ident= POINTER;
        }

     /* at this point we should have the name */
     word[NAMESIZE]= 0;

     strcpy( &ps->name,word );

     if(ps->scope != MEMBER && ps->scope != FARG) p= findsym( word );
     if( p && funactive == 0 ) error("Duplicate variable");
     if( *lp == '[' ){  /* array */
        ps->ident= ARRAY;
        next();
        next();
        if( match("]") ) ;
        else{
           ps->size= (int) const_exp();
           next();
           if( !( match("]"))) error("Missing ]");
           }

        if( ps->scope == FARG ){  /* func arg arrays are pointers */
           ps->indirect += 1;
           ps->ident= POINTER;
           }

        if( *lp == '[' ){  /* 2 d array */
           ps->size2= ps->size;
           ps->size= 0;
           if( ps->size2 == 0 ) error("Need to specify 1st dimension");
           next();
           next();
           if( match("]") ) ;
           else{
              ps->size=  (int) const_exp();
              next();
              if( !( match("]"))) error("Missing ]");
              }
           }
        } /* end array */

        p= addsym( ps );
        allocate( p );       /* data space allocation */

     /* fix arrays without size after allocating space */
     if( p->ident == ARRAY && p->size == 0 ) p->size = 1;

     /* clear out all but scope, link and type in case there is more */
     ps->indirect= ps->size= ps->size2= ps->ident= ps->offset=
          ps->address= 0;

/*     if( *lp == ';' ) next(); */
     return p;

}

struct SYMBOL * fun( struct SYMBOL *ps ){
     /* define function in symbol table if not there already */
struct SYMBOL *p;
struct SYMBOL vp;    /* for function args */
int d;

  clear( &vp );

  word[NAMESIZE]= 0;
  strcpy( ps->name, word );   /* get name */
  ps->ident= FUNCTION;

  if( ps->scope == 0 ) ps->scope= GLOBAL;

  p= findsym(word);
  next();  /* skip '(' */
  if( p == 0 ) p= addsym( ps );
  else{
     if( p->scope != ps->scope  ||  p->size != ps->size ||
         p->indirect != ps->indirect )
         error("Prev func definition does not match");
     }

  if( *lp != ')' ){
/*     next();   */
     /* parse out variables */
     vp.scope= FARG;
     d= gofigure( &vp );
     if( d == 0 ){
        next();        /* gofig put it back */
        old_fun( p );
        return p;
        }

     if( vp.type != VOID ) fun_or_var( &vp );

     while( 1 ){
        vp.type= vp.sign= 0;
        if( *lp != ','  ) break;
        next();
 /*       next();        */
        gofigure( &vp );
        if( vp.type == 0 ) vp.type= INT;
        fun_or_var( &vp );
        }

     } /* end if paren  */

  if( *lp != ')' ) error("Missing paren");
  next();

/* why didn't we want fun_end here, leaving it out causes the stack offsets
to be incorrect if function proto's have any arguments in them */
  if( *lp == ';' )  fun_end();   /* don't want fun_end /* ok - its a proto */
  else if( *lp == '{' ){      /* more than a proto */
      if( funactive ) error("Nested functions");
      if( p->size2 ) error("Duplicate function name");
      p->size2= 1;            /* flag not just proto */
      next();
      csect();
      /* plabel(findname(p)); */
     /*  nl(); */
      funactive= 1;
      center(findname(p));
      block();
      fun_end();
      }
  else error("Missing semicolon or bracket");
  return p;

}

void old_fun( struct SYMBOL *ps ){

int argc;
struct SYMBOL vp;    /* for function args */

  clear(&vp);

  /* check for errors */
  if( funactive ) {
     error("Nested functions");
     return;
     }
  if( ps->size2 ){
     error("Duplicate function name");
     return;
     }

  ps->size2= 1;
  argc= 1;

  while( *lp == ',' ){      /* count variables */
     next();
     next();
     ++argc;
     }

  if( *lp != ')' ) error("Missing paren");
  next();

  vp.scope= FARG;

  while( argc-- ){
     gofigure( &vp );
     if( vp.type == 0 ) vp.type= INT;
     fun_or_var( &vp );
     if( *lp == ';' ) vp.type= vp.sign= 0;
     else if( *lp != ',' ) error("Missing semicolon");
     next();               /* do another of same type or new type */
     }

  if( *lp != '{' ) error("Missing bracket");
  next();
  csect();
/*  plabel(findname(ps));
  nl(); */
  funactive= 1;
  center(findname(ps));
  block();
  fun_end();    /* clear any FARG types in sym table */

}

struct SYMBOL * fun_or_var( struct SYMBOL *ps ){

int d;
struct SYMBOL *p, *link;
struct SYMBOL v;


  link= p= 0;
  ps->ident= VAR;
  if( ps->type == 0 ){
     next();
     if((d= type()) == 0) error("Missing type keyword");
     ps->type= d;
     }

    /* looking for tag name */
   if( (ps->type == STRUCT || ps->type == UNION) && ps->link == 0 ){
     if( *lp != '*' && *lp != '{' ){
        next();
        p= findsym( word );
        if( p ) {
           if( *lp == '{' ) error("Duplicate variable");
           }
        else if( *lp == '{' ) {
           word[NAMESIZE]= 0;
           p= do_struct( ps, word );
           }
        }
     else if( *lp == '{' ){
        p= do_struct( ps, "$" );
        }
     if( *lp == ';' ) return p;     /* just a definition */
     ps->link= p;                  /* link var to structure */
     ps->ident= VAR;
     }

   while (*lp == '*' ){  /* indirection */
      ps->indirect+= 1;
      next();
      ps->ident= POINTER;
      }


   next();       /* name */

     /* check for pointers to other types, ie function pointer */

     if( match("(")){          /* probably have a fun pointer */
        clear( &v );
        v.scope= ps->scope;
        v.type= LINK;
        next();
        link= var( &v );
        if( *lp != ')' ) error("Missing paren");
        next();
        strcpy( word,"$" );      /* set up name */
        ps->scope= 0;            /* not a real var now */
        }

   if( *lp == '(' ){
      p= fun( ps );
      if( link ) link->link= p;         /* fun pointer */
      return p;
      }

   /* its a variable  */

   p= var( ps );

   if( link ) link->link= p;       /* back link as in pointer to array */

   return p;

}



  /* enter a structure or union definition */
struct SYMBOL * do_struct( struct SYMBOL *ps, char *tag ){
struct SYMBOL *link;
struct SYMBOL v;
/* keep track of offsets of members of a structure */
struct OFFSET offs;

  strcpy( &ps->name, tag );
  ps->ident = DEF;
  link= addsym( ps );            /* add tag name */

  offs.offset= offs.shift= 0;    /* init for new struct definition */
  offs.type= link->type;
                                 /* set up for members */
  clear( &v );
  v.scope= MEMBER;

  next();     /* { */


  while ( lp ){    /* add members */
     if( *lp == '}' ) break;
     gofigure( &v );
     if( v.type == 0 ) v.type= INT;
     varlist( &v, &offs );                 /* varlist eats ; */
     v.type= v.sign= 0;
     }

  next();   /* get } */
  /* terminate the definition with a ENDDEF */
  v.ident= ENDDEF;
  v.link= link;
  strcpy( &v.name,"$$" );
  addsym( &v );

           /* add optional vars in varlist */


  return link;

}




void varlist( struct SYMBOL *p, struct OFFSET *o ){
/* do a list of var declars */
struct SYMBOL *v;
int i;

   do{
     v= fun_or_var( p );

     if( v->scope == MEMBER && o->type == STRUCT){
        if( *lp == ':' ){       /* bitfield type */
           v->type= BIT;
           next(); next();      /* get size */
           i= v->size= (int) const_exp();
           if( i > 15 ) error("Bitfield is too large");
           if( (i + o->shift) > 16 ){     /* next int for bitfield */
              o->offset += SOINT;
              o->shift= 0;
              }
           v->size2= o->shift;            /* store shift value */
           o->shift += i;                 /* update shift value */
           v->offset= o->offset;          /* store offset value */
           if( *lp == ':' ){              /* reset bit alignment */
              o->offset += SOINT;
              o->shift= 0;
              next(); next();
              }

           }
        else{                   /* its not a bitfield value */
        /* are we in middle of bits ? */
           if( o->shift ) o->offset += SOINT;  /* yes advance to next int */
           o->shift= 0;                   /* realign bit fields */
           v->offset= o->offset;
           o->offset += size(v);          /* update offset for next var */
           }
        }       /* end members offsets */


     if( *lp != ',' ) break;
     next() ;                /* one next or error in list a,b,c */
     }while( lp );

/* test correct termination of function block or variable list */
   if( funactive == 2 ){
      if( *lp != '}' ) error("Missing bracket");
      funactive= 0;
      }
   else if( *lp != ';' ) error("Missing semicolon");
   next();     /* } or ; */

}


int size( struct SYMBOL * var ){   /* find sizeof variable */
int i;
extern int c26;
extern int pic;

/* C26 can not address on char boundary so make char's 16 bit */

   if( var->ident == VAR ){
      switch ( var->type ){
         case CHAR: if( c26 ) return SOINT;
                    else return SOCHAR;
         case INT:   return SOINT;
         case BIT:   return SOINT;
         case LONG:  return SOLONG;
         case UNION:   return( size_union( var ) );
         case STRUCT:  return( size_struct( var ));
         }
      }
   else if( var->ident == POINTER ){
      if( pic ) return SOCHAR;
      else return SOP;
      }
   else if ( var->ident == ARRAY ){

      /* get size of one of the elements */
      i= sizeone( var );
      if( var->indirect ) i= SOP;  /* really pointers in array */
      i*= var->size;
      if( var->size2 != 0 ) i*= var->size2;
      return i;
      }

 error("Unknown type for size function");
 return SOINT;
}


int sizeone( struct SYMBOL * var ){ /* size of one array element */
struct SYMBOL one;

     clear( & one );
     one.type= var->type;
     one.ident= VAR;
     one.link= var->link;
     return( size( &one ));
}
