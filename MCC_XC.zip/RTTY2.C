extern void puts();
extern char kbhit();
extern void putchar();
extern char getch();

#define END 143
#define UPSHIFT 27
#define DOWNSHIFT 31
#define ANSWER 109
#define ORIG 111
/* tandy 200 hardware registers */
#define COM 193
#define PORTB 178
#define CSR 176
#define TIMERL 180
#define TIMERH 181

extern char TABLE[];      /* delete this global */

main()      /* call from BASIC with desired function in a register */
{           /* dispatch to selected function */
            /* CALL 60000,function,[arg]    0 - TX, 1 - RX 2-INIT */
            /* pointer to optional argument or return value */
char *p;
char e;
char d;

#asm
   org 60000
   mov  e,a     ; get the mode/function
   mov  c,l     ; get the optional arg
   mov  b,h
#endasm;

      /* mask the function from mode and branch on it */
    if( (d= e & 3) == 2 ){
          init(p,e);
          return;
          }
    if( d == 1 ){
          rttyrx();
          return;
          }
    rttytx();

}


/* globals for tx fifo */
char buf[40];
char bufcnt;   /* how many in buffer */
char spaces;   /* number of spaces in buffer */

bufin( c ) char c; {
   if( c == 8 )    /* delete */
   {
      if( bufcnt )
      {               /* delete in fifo */
         if( buf[--bufcnt] == ' ' ) --spaces;
         puts("\b \b");  /* delete  */
    /*     putchar( c );  putchar(' ');  putchar( c );  */
      }
   }
   else              /* store the data */
   {
      buf[bufcnt]= c;
      ++bufcnt;
      if( c == ' ' || c == END ) ++spaces;
   }
}

bufout(){       /* return one char from fifo */

char *p;
char temp, cnt;

   if( bufcnt == 0 || spaces == 0) return 0;  /* idle char */
   p=buf;
   temp= *p;             /* save desired char */
   cnt= --bufcnt+2;
   while( --cnt )  *p++ = *p;   /* shift all down */
   if( temp == ' ' ) --spaces;
   return temp;
}

lookup( c ) char c; {    /* find C in table */

char indx;

   indx= 0;
   while( indx < 64 )
   {
       if( TABLE[indx] == c ) break;
       ++indx;
   }
   return (indx & 63);    /* mask off bit 7 - return 0 if indx = 64 */

}


rttytx(){     /* send keyinput to rs232 */

char c;
char figs;
char line_len;       /* count the line length */

    39 $ COM;       /* set rts to key up tx */
    #asm
       sta 64766    ; basic copy of command word
    #endasm;

    ORIG $ PORTB;   /* change tones to keep them the same */
    bufcnt= figs= spaces= line_len= 0;      /* init fifo etc. */

    for(;;) /* while(1)  */
    {
       if ( kbhit() && bufcnt < 40 )       /* key pending ? */
       {
          c= getch();
          if( c >= 'a' && c != END ) c= c - 32;  /* convert from lower case */
          bufin( c );                /* insert character */
          if( c == 13 ) crlf();
          else if( c != 8 ) putchar( c );
       }

       if( @COM & 1 )         /* COM tx ready? */
       {
          c= bufout();
          if( c == 13 || c == END || ( c == ' ' && line_len > 60 ))
          {
              sndcom(8);           /* send a rtty crlf equivalent */
              sndcom(2);
              sndcom(31);
             figs= line_len= 0;
          }
          else
          {
             if( c )                        /* check that not null */
             {
                 ++line_len;                /* count sent characters */
                 c= lookup(c);              /* get the rtty value */
                 if( c > 31 && figs == 0 )
                 {
                    sndcom( UPSHIFT );
                    figs= 1;
                 }
                 if( c < 32 && figs )
                 {
                    sndcom( DOWNSHIFT );
                    figs= 0;
                 }
             }
             sndcom(c & 31);       /* send masked to 5 bits */
          }
          
          if( c == END ) break;    /* exit the tx routine */
       }    /* end of COM routine */
    }       /* end loop */
    /* send some idle characters to clear the buffers */
    c= 4;
    while( --c ) sndcom( 0 );

    7 $ COM;       /* clear rts( TX off ) */
    #asm
       sta 64766    ; basic copy of 8251 command word
    #endasm;

    ANSWER $ PORTB;   /* change tones to keep them the same */


}


/*  rtty receive code */
/*  return if any key is pressed */
rttyrx()
{

char a,shift;

    shift= 0;
    for(;;)  /* while( 1 ) */
    {
        if( rcvx() )       /* any characters in rs232 que ? */
        {
             a= rv232c() & 31;
             if( a == UPSHIFT ) shift= 32;
             else if( a == DOWNSHIFT ) shift= 0;
             else if( a == 8 ) crlf();
             else if( a )
             {                 /* print converted char */
                 putchar( TABLE[a+shift]);
             }

        }
        if( kbhit() ) break;   /* return if key is pressed */
    }
}


/* conversion table for RTTY */


#asm
TABLE:     ; not sure where 39 should be - took out bell

   db 0,'E',0
   db 'A SIU',13,'DRJNFCKTZLWHYPQOBG',0
   DB 'MXV',0
   DB 0,'3',0,'- ',39,'87',13,'$4',39,',!:(5'
   DB 34,')2#6019?&',0,'./;',0

#endasm
/*

120 B$="E"+CHR$(0)+"A SIU"+CHR$(13)+"DRJNFCKTZLWHYPQOBG"+CHR$(0)+"MXV"+CHR$(0)
122 B$=B$+CHR$(0)+"3"+CHR$(0)+"- "+CHR$(7)+"87"+CHR$(13)+"$4',!:(5"
+CHR$(34)+")2#6019?&"+CHR$(0)+"./;"+CHR$(0)

*/

init(p,cw)
char *p;
char cw;
{       /* set up the baud rate and 5 char word length */
              /* arg has baud rate, mode should be 130 for baudot */

   /* set up 8251 - command word is mode */
   64 $ COM ;    /* init */
   cw $ COM ;   /* mode */
   7 $ COM ;     /* enables */
   #asm
      sta 64766   ; basic copy of command word
   #endasm;

   /* select answer mode + enable modem */
   ANSWER $ PORTB ;
   /* load the baud rate */
   67 $ CSR ;   /* stop clock */
   *p++ $ TIMERL ;
   *p | 64 $ TIMERH ; /* needs 64 for timer function */
   195 $ CSR ;  /* start clock again */
}
