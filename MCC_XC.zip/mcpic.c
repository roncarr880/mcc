/* dummy file for naming the exe file as mcpic */



